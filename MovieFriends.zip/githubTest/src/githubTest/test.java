package githubTest;

public class test {

	public static void main(String[] args) {


		
		System.out.println("테스트");
		System.out.print("zz");
		System.out.print("ㅗ");
		System.out.println("헬로우");
		
		
		for (int i = 0; i < 10; i++) {
			System.out.println("i:"+i);
		}
		
		
		System.out.println("테스트 2");
		System.out.println("영 테스트");
		System.out.println("테스트3");
		System.out.println("asddasdasd");
		System.out.println("함영훈");
	}
}
