package Controller;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;

import Service.MemberService;
import Service.MemberServiceImpl;
import dao.memberDao;
import model.memberDto;
import view.joinView;
import view.loginView;
import view.movieListView;


public class MemberCtr { //회원관리 
	
	public String id ;
	public boolean loginsucess;
	
	public movieListView mview;

	MemberServiceImpl mService = new MemberService();
	
	public void movieList() {
		mview = new movieListView();
	}
	
	public void login() {
		new loginView();
	}
	
	public void regi() {
		new joinView();
	}

	public boolean idCheck(String id) {
		
		if(mService.getId(id)) {
			this.id = id;
		}
		return mService.getId(id);
	}
	
	
	public void regiAf(String id, String pwd, String name, String email) {
		
		boolean b = mService.addMember(new memberDto(id, pwd, name, email, 0));
		
		if(b) {
			JOptionPane.showMessageDialog(null, "회원가입 성공!!");
			login();
			//new loginview();
		}else {
			JOptionPane.showMessageDialog(null, "회원가입 실패");
			regi();
		}
			
		
	}
}
