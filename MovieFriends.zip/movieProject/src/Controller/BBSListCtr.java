package Controller;

import java.util.ArrayList;
import java.util.List;

import Service.BBSService;
import Service.BBSServiceImpl;
import model.BbsDto;
import model.CommentDto;
import single.singleton;
import view.bbsListView;
import view.commentUpdateView;
import view.contentView;
import view.updateView;
import view.writerView;
import view.searchView;

public class BBSListCtr {

	public String id;
	
	BBSServiceImpl bService = new BBSService();
	
	bbsListView bbsview;
	
	contentView contentview;
	
	public void bbslistview(String id) {
		this.id = id;
		
		List<BbsDto> list = getBbsList();
		
		singleton s = singleton.getInstance();
		
		bbsview = new bbsListView(list);
		
	}
	
	public void writeView(String id) {
		new writerView(id);
	}
	
	public void addbbs(String id, String title, String content) {
		bService.addbbs(id, title, content);
	}
	
	
	
	public void addcount(int seq) {
		bService.addcount(seq);
	}
	public List<BbsDto> getBbsList(){
		
		return bService.getBbsList();
	}
	public void refreshbbs() {
		bbsview.dispose();
		bbslistview(id);
	}
	
	public void contentView(int seq) {
	
		contentview = new contentView(seq);
	}
	
	public void updateView(int seq) {
		new updateView(seq);
	}
	public void updatebbs(int seq, String title,String content) {
		
		bService.updatebbs(seq, title, content);
	}
	public void deletebbs(int seq) {
		bService.deletebbs(seq);
	}
	
	public List<BbsDto> getsearchlist(String str, int option){
		
		return bService.getsearchlist(str, option);
	}
	
	public void searchView(String str, int option) {
		
		new searchView(str, option);
	}
	
	public List<CommentDto> getcomlist(int seq){
		
		return bService.getcomlist(seq);
	}
	
	public void addcomment(int seq,String id,String content) {
		
		bService.addcomment(seq, id, content);
	}
	
	public void refreshcontent(int seq) {
		contentview.dispose();
		contentView(seq);
	}
	
	public void commentView(int seq, String id, int conseq) {
		new view.commentView(seq, id,conseq);
	}
	
	public void deletecomment(int seq) {
		bService.deletecomment(seq);
	}
	
	public void commentupdateView(int seq, int conseq) {
		new commentUpdateView(seq,conseq);
	}
	public void updatecomment(int seq , String content) {
		bService.updatecomment(seq, content);
	}
	
	
}
