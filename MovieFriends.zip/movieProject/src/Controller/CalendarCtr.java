package Controller;

import java.util.List;

import Service.CalendarService;
import Service.CalendarServiceImpl;
import model.calendarDto;

public class CalendarCtr { //상영일자,개봉일자 etc

	CalendarServiceImpl cservice = new CalendarService();
	
	public void calendarView() {
		new view.calendarView();
	}
	
	public List<calendarDto> getevent(){
		
		return cservice.getevent();
		
	}
	
	public void insertevent(calendarDto dto) {
		cservice.insertevent(dto);
	}
	
	public void deleteEvent(int seq) {
		cservice.deleteEvent(seq);
	}
	
	
}
