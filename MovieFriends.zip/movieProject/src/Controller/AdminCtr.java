package Controller;

import view.adminCalendarInsertView;
import view.adminCalendarView;
import view.adminview;

public class AdminCtr {

	public adminCalendarView acv;
	public adminCalendarInsertView aciv;
	
	public void adminview() {
		new adminview();
	}
	
	public void adminCalendarView() {
		
		acv = new adminCalendarView();
	}
	public void adminCalendarInsertView() {
		aciv = new adminCalendarInsertView();
	}
}
