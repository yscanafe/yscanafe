package Controller;

public class MovieCtr {//영화보기를 클릭시 뜨는 창

}
