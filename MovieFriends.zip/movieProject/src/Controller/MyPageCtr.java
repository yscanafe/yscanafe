package Controller;


import java.util.List;

import Service.MyPageService;
import Service.MyPageServiceImpl;
import model.InterestDto;
import model.WatchDto;
import view.mypageView;



public class MyPageCtr {//로그인시 self history


	MyPageServiceImpl interestService = new MyPageService();
	
	/*public void Mypage() {
		new view.mypageView(ilist, wlist);
	}*/
	public void getMyPage() {
		List<InterestDto> ilist = interestService.getInterestlist();
		List<WatchDto> wlist = interestService.getWatchlist();
		new mypageView(ilist, wlist);
	}
	/*public void getWatchlist() {
		
		new mypageView(null, wlist);
	}*/
	
}
