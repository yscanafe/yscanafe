package dao;

import model.MyPageDto;

public interface MyPageDaoImpl {

	public MyPageDto get(int seq);
	
}
