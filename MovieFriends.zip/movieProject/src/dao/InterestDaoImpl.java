package dao;


import java.util.List;


import model.InterestDto;

public interface InterestDaoImpl {

	public InterestDto getInterest(int seq);
	public List<InterestDto> getInterestlist();
	public boolean writeInterest(InterestDto dto);
	public boolean deleteInterest(int seq);
}
