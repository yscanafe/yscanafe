package dao;

import java.util.List;


import model.WatchDto;

public interface WatchDaoImpl {

	public WatchDto getWatch(int seq);
	public List<WatchDto> getWatchlist();
	public boolean writeWatch(WatchDto dto);
	public boolean deleteWatch(int seq);
}
