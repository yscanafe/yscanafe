package dao;

import model.MyPageDto;

public class MyPageDao implements MyPageDaoImpl{

	@Override
	public MyPageDto get(int seq) {
		// TODO Auto-generated method stub
		return null;
	}


}
