package dao;

import java.util.List;

import model.calendarDto;

public interface calendarDaoImpl {

	
	
	public List<calendarDto> getevent();
	
	public void insertevent(calendarDto dto);
	
	public void deleteEvent(int seq);

	
	
	
	
}
