package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import db.DBClose;
import db.DBConnection;

import model.calendarDto;

public class calendarDao implements calendarDaoImpl{

	@Override
	public List<calendarDto> getevent() {
		
		String sql = " SELECT * "
				+ " FROM MOVIECALENDAR "
				+ " ORDER BY STARTDAY";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		List<calendarDto> list = new ArrayList<calendarDto>();
		
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while (rs.next()) {
				
				calendarDto  dto =new calendarDto(
										 rs.getInt(1),
										 rs.getString(2),
										 rs.getString(3),
										 rs.getString(4),
										 rs.getString(5));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}

	@Override
	public void insertevent(calendarDto dto) {
		
		String name = dto.getEventname();
		String startday = dto.getStartday();
		String endday = dto.getEndday();
		String color = dto.getColor();
		
		boolean b =false;
		
		String sql =  " INSERT INTO MOVIECALENDAR"
				+ " VALUES(SEQ_CALENDAR.NEXTVAL,'"+name+"', '"+startday+"', '"+endday+"', '"+color+"' ) ";
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		
		try {
			stmt = conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			if (stmt!=null) {
				
				JOptionPane.showMessageDialog(null, "등록되었습니다");
			
			}
			DBClose.close(stmt, conn, null);
		}
	
	}

	@Override
	public void deleteEvent(int seq) {
		// TODO Auto-generated method stub
		
		
		String sql = " DELETE MOVIECALENDAR "
					+ " WHERE SEQ = "+ seq;  
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			JOptionPane.showMessageDialog(null, "삭제되었습니다");
			DBClose.close(stmt, conn, null);
		}
	}

	
	
	
}
