package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.DBClose;
import db.DBConnection;
import model.InterestDto;
import model.WatchDto;

public class WatchDao implements WatchDaoImpl{

	@Override
	public WatchDto getWatch(int seq) {
		String sql = " SELECT ID, TITLE, ACTER,  POINT, WDATE"
				+ " FROM WATCHTABLE "
				+ " WHERE SEQ=? ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		WatchDto dto = null;
		
		try {			
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);	
			
			psmt.setInt(1, seq);			
			rs = psmt.executeQuery();
			
			
			
			while(rs.next()){				
				String id = rs.getString(1);
				String title = rs.getString(2);
				String acter = rs.getString(3);			
				String point = rs.getString(4);
				String wdate = rs.getString(5);
				
				dto = new WatchDto();
			}
			
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally{
			DBClose.close(psmt, conn, rs);		
		}
		return dto;
	}

	@Override
	public List<WatchDto> getWatchlist() {
		List<WatchDto> list = new ArrayList<WatchDto>();
		
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = " SELECT SEQ, ID, TITLE, ACTER, "
				+ " POINT, WDATE, DEL "
				+ " FROM WATCHTABLE ";
	

		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery(sql);
			
			while(rs.next()) {
				
				WatchDto dto = new WatchDto(rs.getInt(1),
										rs.getString(2), rs.getString(3), 
										rs.getString(4), rs.getString(5), 
										rs.getString(6), rs.getInt(7));
				
				list.add(dto);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		
		return list;
	}

	@Override
	public boolean writeWatch(WatchDto dto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWatch(int seq) {
		// TODO Auto-generated method stub
		return false;
	}

}
