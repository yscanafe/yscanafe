package dao;

public class AdminDao implements AdminDaoImpl {

}
