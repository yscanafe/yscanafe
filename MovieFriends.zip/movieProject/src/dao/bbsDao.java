package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.DBClose;
import db.DBConnection;
import model.BbsDto;
import model.CommentDto;

public class bbsDao implements bbsDaoImpl {

	
	
	@Override
	public List<BbsDto> getBbsList() {
		
		String sql = " SELECT SEQ,ID,TITLE,CONTENT, "
				+ " WDATE, DEL, READCOUNT "
				+ " FROM BBS "
				+ " ORDER BY WDATE DESC ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		List<BbsDto> list = new ArrayList<BbsDto>();
		
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while (rs.next()) {
				
				BbsDto  dto =new BbsDto(rs.getInt(1),
										 rs.getString(2),
										 rs.getString(3),
										 rs.getString(4),
										 rs.getString(5),
										 rs.getInt(6),
										 rs.getInt(7));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}

	@Override
	public void addbbs(String id,String title, String content) {
		
		
		String sql = " INSERT INTO BBS(SEQ,ID,TITLE,CONTENT,WDATE,DEL,READCOUNT) "
				+ " VALUES(SEQ_BBS.NEXTVAL,'"+id+"','"+title+"','"+content+"',SYSDATE,0,0) "; 
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
	}

	@Override
	public void addcount(int seq) {
	
		String sql =  " UPDATE BBS "
				+ " SET READCOUNT = READCOUNT+1 "
				+ "WHERE SEQ = "+ seq; 
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
		
	}

	@Override
	public void updatebbs(int seq, String title, String content) {
		
		String sql = " UPDATE BBS "
				+ " SET TITLE = '"+title+"', CONTENT = '"+content+"', WDATE = SYSDATE "
						+ "WHERE SEQ = "+ seq; 
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
	}

	@Override
	public void deletebbs(int seq) {
		
		String sql = " UPDATE BBS "
				+ " SET TITLE = '"+"이글은 삭제되었습니다"+"', DEL = "+1+" "
				+ "WHERE SEQ = "+ seq;  
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
	}

	@Override
	public List<BbsDto> getsearchlist(String str, int option) {
		String sql = null;
		
		if (option ==1) {
			
			sql = " SELECT SEQ,ID,TITLE,CONTENT, "
					+ " WDATE, DEL, READCOUNT "
					+ " FROM BBS "
					+ " WHERE TITLE LIKE '"+"%"+str+"%"+"'"
					+ " ORDER BY WDATE DESC ";
			
		}
		else if (option ==2) {
			
			sql = " SELECT SEQ,ID,TITLE,CONTENT, "
					+ " WDATE, DEL, READCOUNT "
					+ " FROM BBS "
					+ " WHERE CONTENT LIKE '"+"%"+str+"%"+"'"
					+ " ORDER BY WDATE DESC ";
			
		}
		else if (option ==3) {
			
			sql = " SELECT SEQ,ID,TITLE,CONTENT, "
					+ " WDATE, DEL, READCOUNT "
					+ " FROM BBS "
					+ " WHERE TITLE LIKE '"+"%"+str+"%"+"' OR CONTENT LIKE '"+"%"+str+"%"+"'"
					+ " ORDER BY WDATE DESC ";
			
						
		}
		else if (option ==4) {
			
			sql = " SELECT SEQ,ID,TITLE,CONTENT, "
					+ " WDATE, DEL, READCOUNT "
					+ " FROM BBS "
					+ " WHERE ID = '"+str+"'"
					+ " ORDER BY WDATE DESC ";
			
			
		}
		
		
		
		
		

		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		List<BbsDto> list = new ArrayList<BbsDto>();
		
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while (rs.next()) {
				
				BbsDto  dto =new BbsDto(rs.getInt(1),
										 rs.getString(2),
										 rs.getString(3),
										 rs.getString(4),
										 rs.getString(5),
										 rs.getInt(6),
										 rs.getInt(7));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}

	
	//댓글
	
	@Override
	public List<CommentDto> getcomlist(int seq) {
		String sql = " SELECT * "
				+ " FROM BBSCOMMENT "
				+ " WHERE SEQ = "+ seq
				+ " ORDER BY WDATE ";
		
		Connection conn = DBConnection.getConnection();
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		
		List<CommentDto> list = new ArrayList<>();
		
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while (rs.next()) {
				
				CommentDto  dto =new CommentDto(rs.getInt(1),
										 rs.getInt(2),
										 rs.getString(3),
										 rs.getString(4),
										 rs.getString(5),
										 rs.getInt(6));
				
				list.add(dto);
				
			}
		
		
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(psmt, conn, rs);
		}
		
		return list;
	}

	@Override
	public void addcomment(int seq, String id, String content) {
		// TODO Auto-generated method stub
		String sql = " INSERT INTO BBSCOMMENT(COMSEQ,SEQ,ID,CONTENT,WDATE,DEL) "
				+ " VALUES(COMSEQ_COMMENT.NEXTVAL,"+seq+",'"+id+"','"+content+"',SYSDATE,0) "; 
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
	}

	@Override
	public void deletecomment(int seq) {
	
		String sql = " UPDATE BBSCOMMENT "
				+ " SET CONTENT = '"+"이 댓글은 삭제되었습니다"+"', DEL = "+1+" "
				+ "WHERE COMSEQ = "+ seq;  
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
		
	}

	@Override
	public void updatecomment(int seq, String content) {
		// TODO Auto-generated method stub
		String sql = " UPDATE BBSCOMMENT "
				+ " SET CONTENT = '"+content+"' "
				+ " WHERE COMSEQ = "+ seq;  
		
		Connection conn = DBConnection.getConnection();
		Statement stmt = null;
		
		try {
			stmt =conn.createStatement();
			stmt.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			DBClose.close(stmt, conn, null);
		}
	}
	
	
	
	

	

	
	
	
}
