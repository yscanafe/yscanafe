package dao;

public interface AdminDaoImpl {

}
