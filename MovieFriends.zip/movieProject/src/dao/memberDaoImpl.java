package dao;



import java.util.List;

import model.memberDto;

public interface memberDaoImpl {

	public boolean getId(String id);
	
	public boolean addMember(memberDto dto);
	
	public memberDto login(memberDto dto);
	
	public String getLoginId();
	
	public void setLoginId(String loginId);
	
	
}
