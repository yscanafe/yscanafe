package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.DBClose;
import db.DBConnection;

import model.InterestDto;

public class InterestDao implements InterestDaoImpl{

	@Override
	public InterestDto getInterest(int seq) {
		String sql = " SELECT ID, TITLE, ACTER, DERECTER, POINT "
				+ " FROM INTERESTTABLE "
				+ " WHERE SEQ=? ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		InterestDto dto = null;
		
		try {			
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);	
			
			psmt.setInt(1, seq);			
			rs = psmt.executeQuery();
			
			
			
			while(rs.next()){				
				String id = rs.getString(1);
				String title = rs.getString(2);
				String ACTER = rs.getString(3);
				String DERECTER = rs.getString(4);				
				String POINT = rs.getString(5);
				
				dto = new InterestDto();
			}
			
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally{
			DBClose.close(psmt, conn, rs);		
		}
		return dto;
	}

	@Override
	public List<InterestDto> getInterestlist() {
		List<InterestDto> list = new ArrayList<InterestDto>();
		
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = " SELECT SEQ, ID, TITLE, ACTER, "
				+ " DERECTER, POINT, DEL "
				+ " FROM INTERESTTABLE ";
	
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery(sql);
			
			while(rs.next()) {
				
				InterestDto dto = new InterestDto(rs.getInt(1),
										rs.getString(2), rs.getString(3), 
										rs.getString(4), rs.getString(5), 
										rs.getString(6), rs.getInt(7));
				
				list.add(dto);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		
		return list;
	}

	@Override
	public boolean writeInterest(InterestDto dto) {
		int count = 0;
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = " INSERT INTO INTERESTTABLE(SEQ, ID, TITLE, ACTER, DERECTER, POINT, DEL) "
				+ " VALUES(SEQ_INTERESTTABLE.NEXTVAL, ?, ?, ?, ?, ?, 0) ";
		
		
		try {
			conn = DBConnection.getConnection();
			System.out.println("2/6 writeBBS Success");
			
			psmt = conn.prepareStatement(sql);
			System.out.println("3/6 writeBBS Success");
			
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getActer());
			psmt.setString(4, dto.getDerecter());
			psmt.setString(5, dto.getPoint());	
			
			count = psmt.executeUpdate();
			System.out.println("4/6 writeBBS Success");
			
		} catch (SQLException e) {			
			System.out.println("writeBBS fail");
		} finally{
			DBClose.close(psmt, conn, rs);			
		}
		
		return count>0?true:false;
	}

	@Override
	public boolean deleteInterest(int seq) {
		String sql = " UPDATE INTERESTTABLE "
				+ " SET DEL=1 "
				+ " WHERE SEQ=? ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		int count = 0;
		
		try {
			conn = DBConnection.getConnection();				
			
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, seq);							
			
			count = psmt.executeUpdate();			
			
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally{
			DBClose.close(psmt, conn, null);				
		}		
		
		return count>0?true:false;	
	

	}

	
}
