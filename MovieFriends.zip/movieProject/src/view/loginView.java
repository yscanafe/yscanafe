package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import single.singleton;


public class loginView extends JFrame implements ActionListener, WindowListener {

	private JTextField idTf, pwTf;
	private JButton loginBtn;
	
	public loginView() {
		super("로그인");
		
		setLayout(null);
		
		JLabel la1 = new JLabel("ID");
		la1.setBounds(30, 30, 30, 30);
		add(la1);
		
		JLabel la2 = new JLabel("PW");
		la2.setBounds(30, 80, 30, 30);
		add(la2);
		
		idTf = new JTextField(10);
		idTf.setBounds(70, 30, 170, 30);
		add(idTf);
		
		pwTf = new JTextField(10);
		pwTf.setBounds(70, 80, 170, 30);
		add(pwTf);
		
		loginBtn = new JButton("로그인");
		loginBtn.setBounds(260, 30, 90, 80);
		loginBtn.addActionListener(this);
		add(loginBtn);
		
		
		setBounds(800, 250, 380, 180);
		setVisible(true);
		addWindowListener(this);

		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object jb = e.getSource();
		singleton s = singleton.getInstance();
		boolean b = s.memCtrl.idCheck(idTf.getText());
		if(jb == loginBtn) {
			if(b){
				JOptionPane.showMessageDialog(null,idTf.getText()+"님 환영합니다" );
				idTf.setText("");
				
				s.memCtrl.loginsucess = true;
				
				this.dispose();
				s.memCtrl.mview.dispose();
				s.memCtrl.movieList();
			}
			else {
				JOptionPane.showMessageDialog(null, "없는 아이디 입니다");
				s.memCtrl.loginsucess = false;
			}
		
			//s.memCtrl.movieList();
		
		}
		
		this.dispose();
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		System.exit(0);
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

}
