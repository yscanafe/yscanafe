package view;

import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ButtonModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.LabelView;

import Controller.BBSListCtr;
import model.BbsDto;
import model.memberDto;
import single.singleton;

public class movieListView extends JFrame implements WindowListener,ActionListener,ChangeListener {
			
		
	String imgName[] = { 
			"1987.jpg","강철비.jpg","나는내일어제의너와만난다.jpg","남한산성.jpg","독전.jpg",
			"라라랜드.jpg","레옹.jpg","미드나잇선.jpg","반드시잡는다.jpg","범죄도시.jpg",
			"아이캔온리이매진.jpg","아이필프리티.jpg","악마를보았다.jpg","잉글랜드이즈마인.jpg","제인갓어건.jpg",
			"킬러의보디가드.jpg","킬링디어.jpg","택시운전사.jpg","하나그리고둘.jpg","햄스테드.jpg",
			}; // 나중에 DB에 저장..
	JButton imgBtn[] = new JButton[imgName.length]; //영화 버튼들.
	int i; //for문..
	
	//로그인 , 회원가입 버튼
	JButton loginBtn,accountBtn;
	// 로그인후 id 보여줌
	JLabel loginId;
	
	//관리자 버튼
	JButton adminBtn;
	
	//영화리스트, 게시판 ,달력,마이페이지 메뉴 버튼
	JButton movieBtn,bbsBtn,calendarBtn,mypageBtn;
	
	Image Title; // movie friend image화
	
	singleton s = singleton.getInstance();
	
	public movieListView() {
		super("Moive View");
		setLayout(null);
		

		Toolkit tk = Toolkit.getDefaultToolkit();
		Title = tk.getImage("무제.png");
		
			
		Panel first = new Panel(); //첫번째 패널 각종 버튼들이 들어갈 곳.
		
		loginBtn = new JButton("로그인");
		accountBtn = new JButton("회원가입");
		movieBtn = new JButton("영화");
		bbsBtn = new JButton("게시판");
		calendarBtn = new JButton("달력");
		mypageBtn = new JButton("마이페이지");
		
		//관리자 버튼 Auth if문으로 비교해서 setvisible 조절 기본값 :false
		adminBtn= new JButton("관리자모드");
		adminBtn.setBounds(1400, 5, 100, 30);
		adminBtn.setVisible(true);
		add(adminBtn);
		adminBtn.addActionListener(this);
		
		
		loginBtn.setSize(90, 30);
		accountBtn.setSize(90, 30);
		movieBtn.setSize(90, 40);
		bbsBtn.setSize(90, 40);
		calendarBtn.setSize(90, 40);
		mypageBtn.setSize(90, 40);
		
		calendarBtn.addActionListener(this);
		
		bbsBtn.addActionListener(this);
		
		loginId = new JLabel(s.memCtrl.id+"님 환영합니다.");
		loginId.setBounds(1150, 5, 90, 30);
		loginId.setVisible(false);
		add(loginId);
		
		
		if (s.memCtrl.loginsucess) {
			loginBtn.setVisible(false);
			accountBtn.setVisible(false);
			loginId.setVisible(true);
	
		}
		else {
			loginBtn.setVisible(true);
			accountBtn.setVisible(true);
		}
		
		mypageBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				s.myPageCtrl.getMyPage();
			}
		});
		
		loginBtn.setLocation(1150, 5);
		loginBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				s.memCtrl.login();
				
			
			}
		});
		add(loginBtn);
		accountBtn.setLocation(1250, 5);
		accountBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				s.memCtrl.regi();
			}
		});
		add(accountBtn);
		
		
		first.add(bbsBtn);
		first.add(calendarBtn);
		first.add(movieBtn);
		first.add(mypageBtn);
		//first.add(loginBtn);
		//first.add(accountBtn);
		first.setBounds(0, 0, 700, 30);
		add(first);
		
		JPanel MovieList = new JPanel(new GridLayout(4, 5)); // 영화 목록이 들어갈 패널.
		
		MovieList.setBounds(90, 160, 1400, 600);
	
		// Image 추출 -> resize -> button생성 -> 이미지 삽입
		for ( i = 0; i < imgName.length; i++) {
					
		String imgPath = ("\\\\192.168.30.34\\공유\\1차프로젝트\\image\\"+imgName[i]);
		
		//imageicon 객체를 생성
		ImageIcon orginImg = new ImageIcon(imgPath);
		//ImageIcon에서 image를 추출
		Image orgin = orginImg.getImage();
		//추출된 image의 크기를 조절하여 새로운 image객체 생성
		Image changeImg = orgin.getScaledInstance(200, 220, Image.SCALE_SMOOTH);
		//새로운 Image로 ImageIcon객체를 생성
		ImageIcon Icon = new ImageIcon(changeImg);
		
		imgBtn[i] = new JButton(Icon);
		//imgBtn[i].setLabel(imgName[i]);
		//imgBtn[i].setIcon(Icon);
		imgBtn[i].setSize(220,250);
		//imgBtn[i].setBorderPainted(false);
		imgBtn[i].setContentAreaFilled(false);
		//imgBtn[i].setFocusPainted(false);
		//imgBtn[i].setOpaque(false);
		//imgBtn[i].getModel().addChangeListener(this);
		imgBtn[i].addActionListener(this);
		
		MovieList.add(imgBtn[i]);
		
		
		}
		// rollover 등 event를 삽입하는 곳
		/*for ( i = 0; i < imgBtn.length; i++) {
			
	
		imgBtn[i].getModel().addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				ButtonModel model = (ButtonModel)e.getSource();
				if(model.isRollover()) {
					try {
						imgBtn[i].setRolloverIcon(new ImageIcon(ImageIO.read(new File("D://project/image/레옹.jpg"))));
						imgBtn[i].setRolloverEnabled(true);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.out.println(imgBtn[i]+"rollover");
				}
				
			}
		});
		}*/
		
		
		JScrollPane MovieListScr = new JScrollPane(MovieList);
		MovieListScr.setBounds(30, 200, 1450, 550);
		MovieListScr.setPreferredSize(new Dimension(1450, 650));
		add(MovieListScr);
		
		setBounds(0, 0, 1600, 900);
		setVisible(true);
		addWindowListener(this);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		for (int i = 0; i < imgBtn.length; i++) {
			
		
		if(obj==imgBtn[i]) {
			System.out.println("imgBtn"+i);
			//imgBtn[i].setText(imgName[i]);
			
			JOptionPane.showMessageDialog(null,imgName[i]);
		
		}
				
		}
		
		if (obj == calendarBtn) {
			s.calCtrl.calendarView();
		}
		else if(obj == mypageBtn) {
			
			
			
		}
		else if (obj == adminBtn) {
			
			s.adminCtrl.adminview();
			
		}
		else if(obj == bbsBtn) {	
			//if문으로 guest일때 분기
			
			s.bbsCtrl.bbslistview("guest");
			
		}
		

			
	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		ButtonModel model = (ButtonModel)e.getSource();
		if(model.isRollover()) {
			try {
				imgBtn[i].setRolloverIcon(new ImageIcon(ImageIO.read(new File("D://project/image/레옹.jpg"))));
				imgBtn[i].setRolloverEnabled(true);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println(imgBtn[i]+"rollover");
		}
		
		
	}
		
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		
		int imgWidth = Title.getWidth(this); // 이미지 폭 취득
		int imgHeight = Title.getHeight(this); // 이미지 높이 취득
		g.drawImage(Title, (getWidth()-imgWidth)/2, (getHeight()-imgHeight)/10, this); //타이이미지 위치설
		
	}



	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {
		System.exit(0);

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	




	

}
