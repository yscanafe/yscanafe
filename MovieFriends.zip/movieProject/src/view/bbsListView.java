package view;

import java.awt.Choice;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import model.BbsDto;
import single.singleton;



public class bbsListView extends JFrame implements ActionListener,MouseListener,ItemListener {

	private JTable jtable;
	private JScrollPane jscrpane;
	
	String columnNames[] = { "번호", "제목", "작성자"};
	//String columnNames[] = { "번호","말머리","제목", "작성자","추천"};
	
	JButton insertBtn, logout,searchBtn;
	
	JTextField searchbar;
	
	JButton movieBtn,bbsBtn,calendarBtn,mypageBtn;
	
		
	Object rowdata[][];
	
	int del[],row[],option = 1;
	
	Choice choice;
	
	DefaultTableModel model;
	
	List<BbsDto> list;
	
	//MemberDao mdao = MemberDao.getInstance();
	
	public bbsListView(List<BbsDto> list) {
		super ("게시판");
		
		setLayout(null);
		
		this.list = list;
		
		
		JLabel label = new JLabel("게시판");
		label.setBounds(10, 10, 120, 15);
		add(label);
		
		
		int bbsnum = 1;
		
		rowdata = new Object[list.size()][4]; 	// 테이블의 2차원 배열 생성
		row = new int[list.size()];
		del = new int[list.size()];
		
		for (int i = 0; i < list.size(); i++) {
			BbsDto dto = list.get(i);
			
			rowdata[i][0] = bbsnum;
			rowdata[i][1] = dto.getTitle();
			rowdata[i][2] = dto.getId();
			row[i] = dto.getSeq();
			del[i] = dto.getDel();
			bbsnum++;
		}
		//테이블의 폭을 설정하기 위한 MODEL
		model = new DefaultTableModel(columnNames, 0) {
			public boolean isCellEditable(int i,int c) {
				return false;
			}
		};
		
		model.setDataVector(rowdata, columnNames);
		
		// 테이블 생성
		
		jtable = new JTable(model);
		// 컬럼 넓이 설정
		jtable.getColumnModel().getColumn(0).setMaxWidth(50);	// 글번호 폭
		jtable.getColumnModel().getColumn(1).setMaxWidth(500);	// 글제목 폭
		jtable.getColumnModel().getColumn(2).setMaxWidth(200);	// 글쓴이 폭
		
		// 테이블 안의 컬럼의 align 설정
		DefaultTableCellRenderer celaligncenter = new DefaultTableCellRenderer();
		celaligncenter.setHorizontalAlignment(JLabel.CENTER);
		
		jtable.getColumn("번호").setCellRenderer(celaligncenter);
		jtable.getColumn("작성자").setCellRenderer(celaligncenter);
		
		jtable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		jtable.addMouseListener(this);
		
		
		jscrpane = new JScrollPane(jtable);
		jscrpane.setBounds(10, 50, 600, 300);
		
		add(jscrpane);
		
		insertBtn = new JButton("글쓰기");
		insertBtn.setBounds(10, 400, 100, 30);
		
		singleton s = singleton.getInstance();
		if(s.memCtrl.loginsucess) {
			logout = new JButton("로그아웃");
		}
		
		else {
			logout = new JButton("로그인");
		}
		
		
		logout.setBounds(510, 10, 100, 30);
		
		searchBtn = new JButton("검색");
		searchBtn.setBounds(510, 400, 100, 30);
		
		insertBtn.addActionListener(this);
		logout.addActionListener(this);
		searchBtn.addActionListener(this);
		
		
		movieBtn = new JButton("영화");
		bbsBtn = new JButton("게시판");
		calendarBtn = new JButton("달력");
		mypageBtn = new JButton("마이페이지");
		
		movieBtn.setBounds(10, 10, 100, 30);
		bbsBtn.setBounds(120, 10, 100, 30);
		calendarBtn.setBounds(230, 10, 100, 30);
		mypageBtn.setBounds(340, 10, 100, 30);
		
		movieBtn.addActionListener(this);
		bbsBtn.addActionListener(this);
		calendarBtn.addActionListener(this);
		mypageBtn.addActionListener(this);
		
		add(bbsBtn);
		add(calendarBtn);
		add(movieBtn);
		add(mypageBtn);
			
		add(insertBtn);
		add(logout);
		add(searchBtn);
		
		searchbar = new JTextField();
		searchbar.setBounds(300, 400, 200, 30);
		//searchbar.setHorizontalAlignment(JTextField.RIGHT);
		add(searchbar);
		
		
		choice = new Choice();
		
		choice.add("제목");
		choice.add("내용");
		choice.add("제목+내용");
		choice.add("작성자");
		
		choice.setBounds(200, 403, 90, 30);
		choice.addItemListener(this);
		
		
		add(choice);

		
		
		
		getContentPane().setBackground(Color.white);
		setBounds(450, 250, 640, 480);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		singleton s= singleton.getInstance();
		
		if (btn.getLabel().equals("글쓰기")) {
			
			if(s.memCtrl.loginsucess) {
				s.bbsCtrl.writeView(s.memCtrl.id);
			}
			else {
				JOptionPane.showMessageDialog(null, "로그인 해주십시오.");
			}
	
		}
		else if (btn.getLabel().equals("로그인")) {
			
			s.memCtrl.login();
			this.dispose();
			
		}
		else if(btn.getLabel().equals("로그아웃")) {
			System.exit(0);
		}
		
		else if (btn.getLabel().equals("검색")) {
			
			String str = searchbar.getText();
			
			s.bbsCtrl.searchView(str,option);
			
			
		}
		else if (btn.getLabel().equals("영화")) {
			this.dispose();
			new movieListView();
		}
		else if (btn.getLabel().equals("게시판")) {
			this.dispose();
			new bbsListView(list);
		}
		else if (btn.getLabel().equals("달력")) {
			this.dispose();
			new calendarView();
		}
		else if (btn.getLabel().equals("마이페이지")) {
			this.dispose();
		//	new mypageView();
		}

		
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		
		singleton s = singleton.getInstance();
		
		int seq = (int) row[jtable.getSelectedRow()];

		if (list.get(jtable.getSelectedRow()).getDel()==1) {
			return;
		}
	
		s.bbsCtrl.addcount(seq);
		
		s.bbsCtrl.contentView(seq);
	
		
		
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void itemStateChanged(ItemEvent e) {
		Choice ch = (Choice) e.getSource();
		String str = ch.getSelectedItem();
		
		if (str.equals("제목")) {
			option = 1;
			
		}
		else if (str.equals("내용")) {
			option = 2;
			
		}
		else if (str.equals("제목+내용")) {
			option =3;
		}
		else if (str.equals("작성자")) {
			option = 4;
		}
		else if (str.equals("말머리")) {
			option = 5;
		}
		
	}

}
