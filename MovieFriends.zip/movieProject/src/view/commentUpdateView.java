package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import db.DBClose;
import db.DBConnection;
import single.singleton;

public class commentUpdateView extends JFrame implements ActionListener {

	
	JTextArea contentAr;
	
	JButton updateBtn,closeBtn;
	

	int seq,conseq;
	
public commentUpdateView(int seq, int conseq) {
		
		super("수정창");
		
		this.seq = seq;
		this.conseq = conseq;
		
		setLayout(new GridLayout(2,1));
		
		
		contentAr = new JTextArea("댓글수정");
		add(contentAr);
		
		
		JPanel pan = new JPanel(new GridLayout(1, 2));
		
		updateBtn = new JButton("확인");
		
		closeBtn = new JButton("취소");
		
		updateBtn.addActionListener(this);
		

		
		closeBtn.addActionListener(this);
		
		pan.add(updateBtn);
	
		pan.add(closeBtn);
		
		add(pan);
		
		setBounds(400, 200, 220	, 120);
		//getContentPane().setBackground(Color.white);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {

		
		JButton btn = (JButton) e.getSource();
		singleton s = singleton.getInstance();
		
		if (btn.getLabel().equals("확인")) {
			
			String content = contentAr.getText();
			
			s.bbsCtrl.updatecomment(seq, content);
			
			this.dispose();
			
			s.bbsCtrl.refreshcontent(conseq);
			
		}
		else if (btn.getLabel().equals("취소")) {
			
			this.dispose();
			
		}

	}

}
