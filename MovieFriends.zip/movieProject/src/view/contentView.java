package view;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


import db.DBClose;
import db.DBConnection;
import model.BbsDto;
import model.CommentDto;
import single.singleton;



public class contentView extends JFrame implements ActionListener,MouseListener,MouseMotionListener {

	JLabel writer,idLb,num,contentLb,titleLb,wdateLb,wdate,countLb,count;
	
	JLabel comment_idLabel;
	
	
	//첨부파일
	JLabel chumbu;
	JButton chumbubtn;
	
	JButton chuchagi;
	JButton chuchunsu;
	
	JTextField writeTf,titleTf;
	
	JTextArea contentAr,titleAr;
	
	JTextArea comment_content;
	
	JScrollPane jscrpane;
	
	JButton registerBtn,closeBtn;
	
	JButton commentBtn;
	
	JViewport jv;
	
	List<BbsDto> list;
	
	String id,title,content,realwdate,realcount;
	
	int seq,row[],del[];
	
	int x,y;
	
	// 댓글 창
	
	String columnNames[] = { "번호","작성자" ,"댓글 내용","작성 날짜"};
	
	DefaultTableModel model;
	
	Object rowdata[][];
	
	JTable jtable;
	
    List<CommentDto> comList;

	singleton s = singleton.getInstance();
	
	public contentView(int selectSeq) {
		super("contentView");
		
		setLayout(null);
		
		
		
		list = s.bbsCtrl.getBbsList();
	
		this.seq = selectSeq;
		
		for (int i = 0; i < list.size(); i++) {
			BbsDto bdto = list.get(i);
			
			if (selectSeq == bdto.getSeq()) {
				
				id = bdto.getId();
				content = bdto.getContent();
				title = bdto.getTitle();
				realwdate = bdto.getWdate();
				realcount = String.valueOf(bdto.getReadcount());
				break;
			}
						
		}
		
		
		idLb = new JLabel(id);
		writer = new JLabel("작성자 : ");
		contentLb = new JLabel("내용 ");
		titleLb = new JLabel("제목 ");
		
		wdateLb = new JLabel("작성일 : ");
		wdate = new JLabel(realwdate);
		
		countLb = new JLabel("조회수 : ");
		count = new JLabel(realcount);
		
		chumbu = new JLabel("첨부파일");
		chumbu.setBounds(100, 160, 70, 30);
		add(chumbu);
		
		//첨부파일 존재시
		if(true) {
			chumbubtn= new JButton("download");
			chumbubtn.setBounds(170, 160, 100, 30);
			add(chumbubtn);
		}
		
		idLb.setBounds(70, 10, 50, 30);
		writer.setBounds(10, 10, 70, 30);
		contentLb.setBounds(10, 160, 70, 30);
		
		wdateLb.setBounds(10, 40, 70, 30);
		wdate.setBounds(70, 40, 150, 30);
		
		countLb.setBounds(10, 70, 70, 30);
		count.setBounds(70, 70, 70, 30);
		
		titleLb.setBounds(10, 100, 70, 30);
		
		add(writer);
		add(idLb);
		add(contentLb);
		add(titleLb);
		
		add(wdateLb);
		add(wdate);
		
		add(countLb);
		add(count);
		
		
		
		
		contentAr = new JTextArea(content);
		//contentAr.setBounds(10, 190, 400, 210);
		contentAr.setLineWrap(true);
		contentAr.setEditable(false);
	
		jscrpane = new JScrollPane(contentAr);
		jscrpane.setBounds(10, 190, 570, 210);
		jscrpane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add(jscrpane);
		
		
		titleAr = new JTextArea(title);
		titleAr.setBounds(10, 130, 570, 30);
		titleAr.setEditable(false);
		
		
		add(titleAr);
		
		registerBtn = new JButton("수정");
		registerBtn.setBounds(10, 710, 100, 30);
		
		closeBtn = new JButton("목록");
		closeBtn.setBounds(480, 710, 100, 30);
		
		closeBtn = new JButton("목록");
		closeBtn.setBounds(480, 710, 100, 30);
		
		
		//추천
		chuchagi = new JButton("추천");
		chuchagi.setBounds(200, 710, 100, 30);
		chuchagi.addActionListener(this);
		add(chuchagi);
		
		chuchunsu = new JButton();
		chuchunsu.setBounds(300, 710, 100, 30);
		chuchunsu.addActionListener(this);
		add(chuchunsu);
		
		
		
		registerBtn.addActionListener(this);
		closeBtn.addActionListener(this);
			
		
		add(registerBtn);
		add(closeBtn);
		// 댓글
		
		comList = s.bbsCtrl.getcomlist(selectSeq);
		
		int comnum = 1;
		
		rowdata = new Object[comList.size()][4]; 	// 테이블의 2차원 배열 생성
		row = new int[comList.size()];
		del = new int[comList.size()];
		
		for (int i = 0; i < comList.size(); i++) {
			CommentDto dto = comList.get(i);
			
			rowdata[i][0] = comnum;
			rowdata[i][1] = dto.getId();
			rowdata[i][2] = dto.getContent();
			rowdata[i][3] = dto.getWdate();
			row[i] = dto.getComseq();
			del[i] = dto.getDel();
			comnum++;
		}
		

		writer = new JLabel("작성자 : ");
		writer.setBounds(10, 600, 70, 30);
		
		add(writer);
		
		comment_idLabel = new JLabel(s.memCtrl.id);
		comment_idLabel.setBounds(65, 600, 100, 30);
		
		add(comment_idLabel);
		
		comment_content = new JTextArea("댓글 입력");
		//comment_content.setBounds(10, 600, 350, 30);
		
		jscrpane = new JScrollPane(comment_content);
		jscrpane.setBounds(10, 640, 465, 50);
		jscrpane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add(jscrpane);
		
		commentBtn = new JButton("댓글 등록");
		commentBtn.setBounds(480, 650, 100, 30);
		commentBtn.addActionListener(this);
		
		add(commentBtn);
		
		model = new DefaultTableModel(columnNames, 0) {
			public boolean isCellEditable(int i,int c) {
				return false;
			}
		};
		
		model.setDataVector(rowdata, columnNames);
		
		jtable = new JTable(model);
		// 컬럼 넓이 설정
		jtable.getColumnModel().getColumn(0).setMaxWidth(50);	// 번호 폭
		jtable.getColumnModel().getColumn(1).setMaxWidth(70);	// 작성자 폭
		jtable.getColumnModel().getColumn(2).setMaxWidth(600);	// 내용 폭
		jtable.getColumnModel().getColumn(3).setMaxWidth(100);	// 작성날짜
		
		jtable.setRowHeight(30);
		
		// 테이블 안의 컬럼의 align 설정
		DefaultTableCellRenderer celaligncenter = new DefaultTableCellRenderer();
		celaligncenter.setHorizontalAlignment(JLabel.CENTER);
		
		jtable.getColumn("번호").setCellRenderer(celaligncenter);
		jtable.getColumn("작성자").setCellRenderer(celaligncenter);
		
		jtable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		jtable.addMouseListener(this);
		
		jtable.addMouseMotionListener(this);
		
		
		
		jscrpane = new JScrollPane(jtable);
		jscrpane.setBounds(10, 400, 570, 200);
		
		add(jscrpane);
		
	
		
		
		setBounds(450, 50, 605, 800);
		//getContentPane().setBackground(Color.white);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		singleton s = singleton.getInstance();
		
		if (btn.getLabel().equals("수정")) {
			if(s.memCtrl.loginsucess) {
			if (idLb.getText().equals(s.memCtrl.id) || s.memCtrl.id.equals("admin")) {
				s.bbsCtrl.updateView(seq);
				this.dispose();
				
			}
		}
			else JOptionPane.showMessageDialog(null, "수정할 권한이 없습니다.");
			
			
		}
		else if (btn.getLabel().equals("목록")) {
			this.dispose();
		}
		else if (btn.getLabel().equals("댓글 등록")) {
			
			int com_seq = seq;
			String com_id = "guest";
			
			if(s.memCtrl.loginsucess) {
			com_id = s.memCtrl.id;
			}
			
			String com_content = comment_content.getText();
			
			if (com_content.equals("")) {
				JOptionPane.showMessageDialog(null, "댓글 내용을 입력하세요.");
				return;
			}
			
			s.bbsCtrl.addcomment(com_seq, com_id, com_content);
			
			s.bbsCtrl.refreshcontent(seq);
			
		}
		
		/*if (btn.getLabel().equals("수정")) {
				
			if (mdao.bbsmember.getId().equals(id)) {
				new updateView(seq);
				this.dispose();
			}
			else JOptionPane.showMessageDialog(null, "수정할 권한이 없습니다.");
			
			
		}
		else if (btn.getLabel().equals("목록")) {
			this.dispose();
		}
		else if (btn.getLabel().equals("댓글 등록")) {
			
			String com_id = mdao.bbsmember.getId();
			int com_seq = seq;
			String com_content = comment_content.getText();
			
			
			String sql = " INSERT INTO BBSCOMMENT(COMSEQ,SEQ,ID,CONTENT,WDATE,DEL) "
					+ " VALUES(COMSEQ_COMMENT.NEXTVAL,"+com_seq+",'"+com_id+"','"+com_content+"',SYSDATE,0) "; 
			
			Connection conn = DBConnection.getConnection();
			Statement stmt = null;
			
			try {
				stmt =conn.createStatement();
				stmt.executeQuery(sql);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}finally {
				DBClose.close(stmt, conn, null);
			}
			
			new contentView(seq);
			this.dispose();
			
			
			
		}
*/
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		
		int seq = (int) row[jtable.getSelectedRow()];
		
		String id = comList.get(jtable.getSelectedRow()).getId();
		
		int conseq = this.seq;
		
		int row = jtable.getSelectedRow();

		if (comList.get(jtable.getSelectedRow()).getDel()==1) {
			return;
			
		}
		
		s.bbsCtrl.commentView(seq, id,conseq);
		
		System.out.println("seq = "+seq +"  row = "+row);
		System.out.println("x = "+x +"  y = "+y);
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseDragged(MouseEvent e) {

		
	}


	@Override
	public void mouseMoved(MouseEvent e) {

		x = e.getX();
		y = e.getY();		
		
		
		
	}

}
