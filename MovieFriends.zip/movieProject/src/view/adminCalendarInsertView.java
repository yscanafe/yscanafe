package view;

import java.awt.Choice;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import model.calendarDto;
import single.singleton;

public class adminCalendarInsertView extends JFrame implements ActionListener {
	
	Label nameLable,startLable,endLabel,colorLabel;
	
	JTextField nameTf,startTf,directorTf,actorTf,timeTf;
	
	JButton closeBtn, insertBtn,idconfig;
	
	Choice colorCh; // 색깔 초이스
	
	Choice startCh1,startCh2,startCh3; // 이벤트 시작 날짜 초이스 연 월 일
	Choice endCh1,endCh2,endCh3;	   // 이벤트 종료 날짜 초이스 연 월 일
	
	
	JTextArea storyTf;
	JScrollPane jscrpane;
	
	singleton s = singleton.getInstance();
	
	public adminCalendarInsertView() {
		super("이벤트 추가");
		
		setLayout(null);
		
		
		
		nameLable = new Label("이벤트 제목 :");
		nameLable.setBounds(30, 50, 80, 30);
		
		startLable = new Label("이벤트 시작 날짜  :");
		startLable.setBounds(30, 100, 100, 30);
		
		endLabel = new Label("이벤트 종료 날짜 :");
		endLabel.setBounds(30, 150, 100, 30);
		
		colorLabel = new Label("이벤트 컬러 :");
		colorLabel.setBounds(30, 200, 80, 30);
		
		
		

		add(nameLable);
		add(startLable);
		add(endLabel);
		add(colorLabel);
		
		

		
		nameTf = new JTextField();
		nameTf.setBounds(140, 50, 180, 30);
		
		
		add(nameTf);
	
		startCh1 = new Choice();
		startCh2 = new Choice();
		startCh3 = new Choice();
		
		startCh1.setBounds(140, 100, 70, 30);
		startCh2.setBounds(215, 100, 50, 30);
		startCh3.setBounds(270, 100, 50, 30);
		
		add(startCh1);
		add(startCh2);
		add(startCh3);
		
		endCh1 = new Choice();
		endCh2 = new Choice();
		endCh3 = new Choice();
		
		endCh1.setBounds(140, 150, 70, 30);
		endCh2.setBounds(215, 150, 50, 30);
		endCh3.setBounds(270, 150, 50, 30);
		
		add(endCh1);
		add(endCh2);
		add(endCh3);
		
		
		choiceinit();
		
		
		
		
		colorCh = new Choice();
		colorCh.setBounds(140, 200, 180, 30);
		
		colorCh.add("YELLOW");
		colorCh.add("BLUE");
		colorCh.add("GREEN");
		colorCh.add("ORANGE");
		colorCh.add("PUPLE");
		colorCh.add("RED");
		
	
		add(colorCh);
	
		
		
		insertBtn = new JButton("추가하기");
		insertBtn.setBounds(10, 270, 100, 30);
		
		closeBtn = new JButton("취소");
		closeBtn.setBounds(310, 270, 100, 30);
		
	
		
		closeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		insertBtn.addActionListener(this);
	
		
		
		add(closeBtn);
		add(insertBtn);
		

		
		setBounds(450, 200, 435, 350);
		
		
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e)  {
		
		String startstr = startCh1.getSelectedItem()+startCh2.getSelectedItem()+startCh3.getSelectedItem();
		
		String endstr = endCh1.getSelectedItem()+endCh2.getSelectedItem()+endCh3.getSelectedItem();
		
		String color = colorCh.getSelectedItem();
		
		String eventname = nameTf.getText();
		
		SimpleDateFormat dt1 = new SimpleDateFormat("yyyy년MM월dd일");
		SimpleDateFormat dt2 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			java.util.Date startdate = dt1.parse(startstr);
			java.util.Date enddate = dt1.parse(endstr);
			
			startstr = dt2.format(startdate);
			endstr = dt2.format(enddate);
			
			calendarDto dto = new calendarDto(0, eventname, startstr, endstr, color); 
			// 0은 seq seq.nextval로 알아서 insert됨
			
			s.calCtrl.insertevent(dto);
			this.dispose();
			s.adminCtrl.acv.dispose();
			s.adminCtrl.adminCalendarView();
			
			//System.out.println(startstr+"~"+endstr);
			
			
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		

		
	}
	
	private void choiceinit() {

		
		
		for (int i = 2010; i < 2021; i++) {
			startCh1.add(i+"년");
			endCh1.add(i+"년");
		}
		for (int i = 1; i < 13; i++) {
			if (i<10) {
				startCh2.add("0"+i+"월");
				endCh2.add("0"+i+"월");
			}
			else {
				startCh2.add(i+"월");
				endCh2.add(i+"월");
			}
			
		}
		
		for (int i = 1; i <= 31; i++) {
			if (i<10) {
				startCh3.add("0"+i+"일");
				endCh3.add("0"+i+"일");
			}
			else {
				startCh3.add(i+"일");
				endCh3.add(i+"일");
			}
			
		}
		
	}

}
