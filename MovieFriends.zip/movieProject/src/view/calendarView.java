package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.calendarDto;
import single.singleton;


class CalendarDataManager{ // 6*7배열에 나타낼 달력 값을 구하는 class
	static final int CAL_WIDTH = 7;
	final static int CAL_HEIGHT = 6;
	int calDates[][] = new int[CAL_HEIGHT][CAL_WIDTH];
	int calYear;
	int calMonth;
	int calDayOfMon;
	final int calLastDateOfMonth[]={31,28,31,30,31,30,31,31,30,31,30,31};
	int calLastDate;
	Calendar today = Calendar.getInstance();
	Calendar cal;
	
	public CalendarDataManager(){ 
		setToday(); 
	}
	public void setToday(){
		calYear = today.get(Calendar.YEAR); 
		calMonth = today.get(Calendar.MONTH);
		calDayOfMon = today.get(Calendar.DAY_OF_MONTH);
		makeCalData(today);
	}
	private void makeCalData(Calendar cal){
		// 1일의 위치와 마지막 날짜를 구함 
		int calStartingPos = (cal.get(Calendar.DAY_OF_WEEK)+7-(cal.get(Calendar.DAY_OF_MONTH))%7)%7;
		if(calMonth == 1) calLastDate = calLastDateOfMonth[calMonth] + leapCheck(calYear);
		else calLastDate = calLastDateOfMonth[calMonth];
		// 달력 배열 초기화
		for(int i = 0 ; i<CAL_HEIGHT ; i++){
			for(int j = 0 ; j<CAL_WIDTH ; j++){
				calDates[i][j] = 0;
			}
		}
		// 달력 배열에 값 채워넣기
		for(int i = 0, num = 1, k = 0 ; i<CAL_HEIGHT ; i++){
			if(i == 0) k = calStartingPos;
			else k = 0;
			for(int j = k ; j<CAL_WIDTH ; j++){
				if(num <= calLastDate) calDates[i][j]=num++;
			}
		}
	}
	private int leapCheck(int year){ // 윤년인지 확인하는 함수
		if(year%4 == 0 && year%100 != 0 || year%400 == 0) return 1;
		else return 0;
	}
	public void moveMonth(int mon){ // 현재달로 부터 n달 전후를 받아 달력 배열을 만드는 함수(1년은 +12, -12달로 이동 가능)
		calMonth += mon;
		if(calMonth>11) while(calMonth>11){
			calYear++;
			calMonth -= 12;
		} else if (calMonth<0) while(calMonth<0){
			calYear--;
			calMonth += 12;
		}
		cal = new GregorianCalendar(calYear,calMonth,calDayOfMon);
		makeCalData(cal);
	}
}


public class calendarView extends CalendarDataManager implements ActionListener {

	
	//영화리스트, 게시판 ,달력,마이페이지 메뉴 버튼
		JButton movieBtn,bbsBtn,calendarBtn,mypageBtn;
		JFrame mainFrame;

		JButton todayBut;
		JLabel todayLab;
		JButton lYearBut;
		JButton lMonBut;
		JLabel curMMYYYYLab;
		JButton nMonBut;
		JButton nYearBut;
	
		JPanel calPanel,eventpanel;
		JLabel eventlist[];
		
		JButton weekDaysName[];
		JButton dateButs[][] = new JButton[6][7];
		
		final String WEEK_DAY_NAME[] = { "SUN", "MON", "TUE", "WED", "THR", "FRI", "SAT" };
		
		ListenForCalOpButtons lForCalOpButtons = new ListenForCalOpButtons();
		
		//이벤트 데이터
		List<calendarDto> eventdb;
		singleton s = singleton.getInstance();
		
		
	public calendarView() {
		mainFrame = new JFrame("달력");
		mainFrame.setLayout(null);
		
		
		JPanel mainpanel = new JPanel();
		
		mainpanel.setLayout(new BorderLayout());
		//mainpanel.setBackground(Color.white);
		mainpanel.setBounds(120, 200, 1000, 500);
		
		mainFrame.add(mainpanel);
		JPanel calOpPanel = new JPanel();
	
		lMonBut = new JButton("<");
		lMonBut.setToolTipText("Previous Month");
		lMonBut.addActionListener(lForCalOpButtons);
		curMMYYYYLab = new JLabel("<html><table width=200><tr><th><font size=5>"+calYear+" 년 "+(calMonth+1)+"월</th></tr></table></html>");
		
		nMonBut = new JButton(">");
		nMonBut.setToolTipText("Next Month");
		nMonBut.addActionListener(lForCalOpButtons);
		
		calOpPanel.setLayout(new GridBagLayout());
		GridBagConstraints calOpGC = new GridBagConstraints();
	
		JLabel todayLab = new JLabel("<html><font color=green>T : Today</html>");
		
		calOpGC.gridx = 1;
		calOpGC.gridy = 2;
		calOpGC.gridwidth = 2;
		calOpGC.gridheight = 1;
		calOpGC.weightx = 1;
		calOpGC.weighty = 1;
		calOpGC.insets = new Insets(5,5,0,0);
		calOpGC.anchor = GridBagConstraints.WEST;
		calOpGC.fill = GridBagConstraints.NONE;
		calOpPanel.add(todayLab,calOpGC);
		
		calOpGC.anchor = GridBagConstraints.CENTER;
		
		calOpGC.gridwidth = 1;
		calOpGC.gridx = 2;
		calOpGC.gridy = 2;
		calOpPanel.add(lMonBut,calOpGC);
		calOpGC.gridwidth = 2;
		calOpGC.gridx = 3;
		calOpGC.gridy = 2;
		calOpPanel.add(curMMYYYYLab,calOpGC);
		calOpGC.gridwidth = 1;
		calOpGC.gridx = 5;
		calOpGC.gridy = 2;
		calOpPanel.add(nMonBut,calOpGC);
		
	
		//이벤트 목록 불러오기
		eventdb = s.calCtrl.getevent();
		
		
		calPanel=new JPanel();
		weekDaysName = new JButton[7];
		for(int i=0 ; i<CAL_WIDTH ; i++){
			weekDaysName[i]=new JButton(WEEK_DAY_NAME[i]);
			weekDaysName[i].setBorderPainted(false);
			weekDaysName[i].setContentAreaFilled(false);
			weekDaysName[i].setForeground(Color.BLACK);
			if(i == 0) weekDaysName[i].setBackground(new Color(200, 50, 50));
			else if (i == 6) weekDaysName[i].setBackground(new Color(50, 100, 200));
			else weekDaysName[i].setBackground(new Color(255, 255, 204));
			weekDaysName[i].setOpaque(true);
			weekDaysName[i].setFocusPainted(false);
			calPanel.add(weekDaysName[i]);
		}
		
		//Color eventcolor = new Color(255, 255, 200);
		
		for(int i=0 ; i<CAL_HEIGHT ; i++){
			for(int j=0 ; j<CAL_WIDTH ; j++){
				dateButs[i][j]=new JButton();
				dateButs[i][j].setBorderPainted(false);
				dateButs[i][j].setContentAreaFilled(false);
				dateButs[i][j].setBackground(Color.WHITE);
				dateButs[i][j].setFocusPainted(false);
				dateButs[i][j].setOpaque(true);
				//dateButs[i][j].addActionListener(lForDateButs);
				calPanel.add(dateButs[i][j]);
			}
		}
		calPanel.setLayout(new GridLayout(0,7,2,2));
		calPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
		
		
		
		
		
		
		Dimension calOpPanelSize = calOpPanel.getPreferredSize();
		calOpPanelSize.height = 50;
		calOpPanel.setPreferredSize(calOpPanelSize);
		
	
		mainpanel.add(calOpPanel,BorderLayout.NORTH);
		mainpanel.add(calPanel,BorderLayout.CENTER);
		
		// 이벤트 목록 패널
		
		eventpanel = new JPanel();
		eventpanel.setBounds(1150, 250, 300, 400);
		eventpanel.setBackground(Color.WHITE);
		eventpanel.setLayout(new GridLayout(6, 1));
		mainFrame.add(eventpanel);
		eventlist = new JLabel[eventdb.size()];
		showCal(eventdb); // 달력을 표시
		
		
		
		
		/*
		eventlist = new JLabel[eventdb.size()];
		
		
		
		for (int i = 0; i < eventdb.size(); i++) {

			eventlist[i] = new JLabel();
			
			eventpanel.add(eventlist[i]);
		}
		
		
		ImageIcon img = new ImageIcon("yellowLine.png");
		ImageIcon img2 = new ImageIcon("redLine.png");
		eventlist = new JLabel[2];
		eventlist[0] = new JLabel(img);
		eventlist[1] = new JLabel(img2);
		eventlist[0].setText(" = 신과함께 무료");
		eventlist[0].setVerticalTextPosition(JLabel.BOTTOM);
		eventlist[1].setText(" = 독전 무료");
		eventlist[1].setVerticalTextPosition(JLabel.BOTTOM);
		eventlist[0].setHorizontalAlignment(JLabel.LEFT);
		eventlist[1].setHorizontalAlignment(JLabel.LEFT);
		
		//eventlist.setHorizontalTextPosition(JLabel.CENTER);
		//eventlist.setVerticalTextPosition(JLabel.BOTTOM);
		
		//eventpanel.add(eventlist[0]);
		eventpanel.add(eventlist[1]);
		*/
		
		
		
		
		//영화리스트,게시판, 달력, 마이페이지

		movieBtn = new JButton("영화");
		bbsBtn = new JButton("게시판");
		calendarBtn = new JButton("달력");
		mypageBtn = new JButton("마이페이지");
		
		movieBtn.setBounds(10, 10, 100, 30);
		bbsBtn.setBounds(120, 10, 100, 30);
		calendarBtn.setBounds(230, 10, 100, 30);
		mypageBtn.setBounds(340, 10, 100, 30);
		
		movieBtn.addActionListener(this);
		bbsBtn.addActionListener(this);
		calendarBtn.addActionListener(this);
		mypageBtn.addActionListener(this);
		
		mainFrame.add(bbsBtn);
		mainFrame.add(calendarBtn);
		mainFrame.add(movieBtn);
		mainFrame.add(mypageBtn);
		
		
		
		mainFrame.setBounds(20, 20, 1500, 800);
		
		mainFrame.setVisible(true);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	
		
		

	}
	private void showCal(List<calendarDto> eventdb){
		
		
		
		for(int i=0;i<CAL_HEIGHT;i++){
			for(int j=0;j<CAL_WIDTH;j++){
				String fontColor="black";
				if(j==0) fontColor="red";
				else if(j==6) fontColor="blue";
				
				/*File f =new File("MemoData/"+calYear+((calMonth+1)<10?"0":"")+(calMonth+1)+(calDates[i][j]<10?"0":"")+calDates[i][j]+".txt");
				if(f.exists()){
					dateButs[i][j].setText("<html><b><font color="+fontColor+">"+calDates[i][j]+"</font></b></html>");
				}
				else dateButs[i][j].setText("<html><font color="+fontColor+">"+calDates[i][j]+"</font></html>");
*/				//JLabel date = new JLabel("<html><font color="+fontColor+">"+calDates[i][j]+"</font></html>");
				
				dateButs[i][j].setText("<html><font color="+fontColor+">"+calDates[i][j]+"</font></html>");
			
				JLabel todayMark = new JLabel("<html><font color=green>Today</html>");
				
				dateButs[i][j].removeAll();
				dateButs[i][j].setIcon(null);
				if(calMonth == today.get(Calendar.MONTH) &&
						calYear == today.get(Calendar.YEAR) &&
						calDates[i][j] == today.get(Calendar.DAY_OF_MONTH)){
					dateButs[i][j].add(todayMark);
					dateButs[i][j].setToolTipText("Today");
					
				}
				
				if(calDates[i][j] == 0) dateButs[i][j].setVisible(false);
				else dateButs[i][j].setVisible(true);
			}
		}
		
		
		try {
			eventcal(eventdb);
			eventshow(eventdb);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		if (btn.getLabel().equals("영화")) {
			mainFrame.dispose();
			//new movieListView();
		}
		else if (btn.getLabel().equals("게시판")) {
			mainFrame.dispose();
			//new bbsView();
		}
		else if (btn.getLabel().equals("달력")) {
			mainFrame.dispose();
			//new calendarView();
		}
		else if (btn.getLabel().equals("마이페이지")) {
			mainFrame.dispose();
			//new mypageView();
		}

	}
	private class ListenForCalOpButtons implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == lMonBut) moveMonth(-1);
			else if(e.getSource() == nMonBut) moveMonth(1);
			
			
			curMMYYYYLab.setText("<html><table width=200><tr><th><font size=5>"+calYear+" 년 "+(calMonth+1)+"월</th></tr></table></html>");
			String ads = (((calMonth+1)<10?"&nbsp;":"")+(calMonth+1));
			
			showCal(eventdb);
		}
	}
	
	private void eventcal(List<calendarDto> eventdb) throws Exception {
		String colorstr = null;
		
		for (int i = 0; i < eventdb.size(); i++) {
			
			calendarDto cal = eventdb.get(i);
			
			if (cal.getColor().equals("YELLOW")) {
				colorstr = "yellowLine.png";
			}
			else if (cal.getColor().equals("GREEN")) {
				colorstr = "greenLine.png";
			}
			else if (cal.getColor().equals("RED")) {
				colorstr = "redLine.png";
			}
			else if (cal.getColor().equals("BLUE")) {
				colorstr = "blueLine.png";
			}
			else if (cal.getColor().equals("ORANGE")) {
				colorstr = "orangeLine.png";
			}
			else if (cal.getColor().equals("PUPLE")) {
				colorstr = "pupleLine.png";
			}
			
			
			
			ImageIcon img = new ImageIcon("\\\\192.168.30.34\\공유\\1차프로젝트\\Line\\"+colorstr);
			
			String day1 = cal.getStartday();
			String day2 = cal.getEndday();
			
			SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
			
			java.util.Date startdate = dt1.parse(day1);
			java.util.Date enddate = dt1.parse(day2);
			java.util.Date currentDate = startdate;
			ArrayList<String> dates = new ArrayList<String>();
			
			while (currentDate.compareTo(enddate)<=0) {
				dates.add(dt1.format(currentDate));
				Calendar c = Calendar.getInstance();
	            c.setTime(currentDate);
	            c.add(Calendar.DAY_OF_MONTH, 1);
	            currentDate = c.getTime();

			
			}
			
			for (int k = 0; k < dates.size(); k++) {
				
		        Calendar c = Calendar.getInstance();
	            c.setTime(dt1.parse(dates.get(k)));
	        
	      
				for(int i1=0;i1<CAL_HEIGHT;i1++){
					for(int j=0;j<CAL_WIDTH;j++){
						
						if(calMonth == (c.get(Calendar.MONTH)) &&
								calYear == c.get(Calendar.YEAR) &&
								calDates[i1][j] == c.get(Calendar.DAY_OF_MONTH))
						
						{
							dateButs[i1][j].setIcon(img);
							dateButs[i1][j].setHorizontalTextPosition(AbstractButton.CENTER);
							
							
						}
						
					}
				}
		        
			}
			
		}
		
				
	}
	
	
	private void eventshow(List<calendarDto> eventdb) throws Exception {
		String eventname;
		String colorstr = null;
		
		
		eventpanel.removeAll();
		eventpanel.revalidate();
		eventpanel.repaint();
		
		
	
		
		
	
		
		
		for (int i = 0; i < eventdb.size(); i++) {
			calendarDto cal = eventdb.get(i);
			

			if (cal.getColor().equals("YELLOW")) {
				colorstr = "yellowLine.png";
			}
			else if (cal.getColor().equals("GREEN")) {
				colorstr = "greenLine.png";
			}
			else if (cal.getColor().equals("RED")) {
				colorstr = "redLine.png";
			}
			else if (cal.getColor().equals("BLUE")) {
				colorstr = "blueLine.png";
			}
			else if (cal.getColor().equals("ORANGE")) {
				colorstr = "orangeLine.png";
			}
			else if (cal.getColor().equals("PUPLE")) {
				colorstr = "pupleLine.png";
			}
			
			
			
			
			ImageIcon img = new ImageIcon("\\\\192.168.30.34\\공유\\1차프로젝트\\Line\\"+colorstr);
			eventname = cal.getEventname();
			
			SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
			
			java.util.Date startdate = dt1.parse(cal.getStartday());
			java.util.Date enddate = dt1.parse(cal.getEndday());
			
			 Calendar startc = Calendar.getInstance();
			 startc.setTime(startdate);
			 Calendar endc = Calendar.getInstance();
			 endc.setTime(enddate);
			
			 
			
			/*if (!eventlist[i].) {
				//eventpanel.repaint();
				eventlist[i].setIcon(null);
				eventlist[i].setText("");
				eventpanel.add(eventlist[i]);
				
			}*/
			/*eventlist[i].setIcon(null);
			eventlist[i].setText("");*/
			
			if(calMonth == startc.get(Calendar.MONTH) &&
					calYear == startc.get(Calendar.YEAR) ||
							calMonth == endc.get(Calendar.MONTH) &&
								calYear == endc.get(Calendar.YEAR)){
				
				
				
				eventlist[i] = new JLabel();
				eventlist[i].setIcon(img);
				eventlist[i].setText(eventname);
				
				eventlist[i].setVerticalTextPosition(JLabel.BOTTOM);
				eventlist[i].setHorizontalAlignment(JLabel.LEFT);
				
				eventpanel.add(eventlist[i]);
				eventpanel.revalidate();
				eventpanel.repaint();
				
			}
			
			
			
		}
		
		
		
	}
	

}

