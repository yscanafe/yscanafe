package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import model.BbsDto;
import single.singleton;



public class searchView extends JFrame implements ActionListener,MouseListener {


	private JTable jtable;
	private JScrollPane jscrpane;
	
	String columnNames[] = { "번호", "제목", "작성자"};
	
	JButton closeBtn;
	
	JTextField searchbar;
		
	Object rowdata[][];
	
	int row[];
	
	DefaultTableModel model;
	
	List<BbsDto> list;
	

	singleton s = singleton.getInstance();
	
	
	public searchView(String str, int option) {
		super ("searchView");
		
		setLayout(null);
		
		JLabel label = new JLabel("검색 결과");
		label.setBounds(10, 10, 120, 15);
		add(label);
		
		
		
		list = s.bbsCtrl.getsearchlist(str, option);
		
		int bbsnum = 1;
		
		rowdata = new Object[list.size()][4]; 	// 테이블의 2차원 배열 생성
		row = new int[list.size()];
		
		for (int i = 0; i < list.size(); i++) {
			BbsDto dto = list.get(i);
			
			rowdata[i][0] = bbsnum;
			rowdata[i][1] = dto.getTitle();
			rowdata[i][2] = dto.getId();
			row[i] = dto.getSeq();
			bbsnum++;
		}
		//테이블의 폭을 설정하기 위한 MODEL
		model = new DefaultTableModel(columnNames, 0) {
			public boolean isCellEditable(int i,int c) {
				return false;
			}
		};
		
		model.setDataVector(rowdata, columnNames);
		
		// 테이블 생성
		
		jtable = new JTable(model);
		// 컬럼 넓이 설정
		jtable.getColumnModel().getColumn(0).setMaxWidth(50);	// 글번호 폭
		jtable.getColumnModel().getColumn(1).setMaxWidth(500);	// 글제목 폭
		jtable.getColumnModel().getColumn(2).setMaxWidth(200);	// 글쓴이 폭
		
		// 테이블 안의 컬럼의 align 설정
		DefaultTableCellRenderer celaligncenter = new DefaultTableCellRenderer();
		celaligncenter.setHorizontalAlignment(JLabel.CENTER);
		
		jtable.getColumn("번호").setCellRenderer(celaligncenter);
		jtable.getColumn("작성자").setCellRenderer(celaligncenter);
		
		jtable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		jtable.addMouseListener(this);
		
		
		jscrpane = new JScrollPane(jtable);
		jscrpane.setBounds(10, 50, 600, 200);
		
		add(jscrpane);
		
		closeBtn = new JButton("종료");
		closeBtn.setBounds(10, 270, 100, 30);
		
		
		closeBtn.addActionListener(this);
		
		
			
		add(closeBtn);
		
		
	
		
		
		
		
		getContentPane().setBackground(Color.white);
		setBounds(450, 250, 640, 350);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		if (btn.getLabel().equals("종료")) {
			this.dispose();
		}

	}


	@Override
	public void mouseClicked(MouseEvent arg0) {
		int seq = (int) row[jtable.getSelectedRow()];
		
		if (list.get(jtable.getSelectedRow()).getDel()==1) {
			return;
		}
		
		s.bbsCtrl.addcount(seq);
		s.bbsCtrl.contentView(seq);
		
		
		
	}


	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
