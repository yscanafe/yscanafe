package view;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import single.singleton;

public class adminview extends JFrame implements ActionListener {

	JButton memberBtn,calendarBtn,movieBtn,closeBtn;
	
	
	singleton s = singleton.getInstance();
	
	public adminview() {
		super("어드민");
		
		setLayout(new FlowLayout(FlowLayout.LEADING));
		
		memberBtn = new JButton("회원관리");
		calendarBtn = new JButton("달력관리");
		movieBtn = new JButton("영화관리");
		closeBtn = new JButton("나가기");
		
		memberBtn.addActionListener(this);
		calendarBtn.addActionListener(this);
		movieBtn.addActionListener(this);
		closeBtn.addActionListener(this);
		
		
		
		add(calendarBtn);
		add(memberBtn);
		add(movieBtn);
		add(closeBtn);
		
		
		setBounds(450, 250, 300, 110);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if (obj == calendarBtn) {
			s.adminCtrl.adminCalendarView();
		}
		else if (obj == memberBtn) {
			new adminMemberView();
		}
		else if (obj == movieBtn) {
			new adminMovieView();
		}
		else if (obj == closeBtn) {
			this.dispose();
		}
	}
	
	
}
