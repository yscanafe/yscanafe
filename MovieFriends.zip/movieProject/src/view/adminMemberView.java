package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class adminMemberView extends JFrame implements ActionListener, MouseMotionListener, MouseListener {

	
	String columnNames[] = { "ID","이름" ,"이메일"};
	
	DefaultTableModel model;
	
	Object rowdata[][];
	
	JTable jtable;
	
	JScrollPane jscrpane;
	
	JButton closeBtn,deleteBtn;
	JPanel btnpanel;
	
	
	
	public adminMemberView() {
		super("회원관리");
		
setLayout(new BorderLayout());
		
		model = new DefaultTableModel(columnNames, 0) {
			public boolean isCellEditable(int i,int c) {
				return false;
			}
		};
		
		model.setDataVector(rowdata, columnNames);
		
		jtable = new JTable(model);
		// 컬럼 넓이 설정
	/*	jtable.getColumnModel().getColumn(0).setMaxWidth(50);	// 번호 폭
		jtable.getColumnModel().getColumn(1).setMaxWidth(70);	// 작성자 폭
		jtable.getColumnModel().getColumn(2).setMaxWidth(0);	// 내용 폭
	*/
		
		jtable.setRowHeight(15);
		
		// 테이블 안의 컬럼의 align 설정
		DefaultTableCellRenderer celaligncenter = new DefaultTableCellRenderer();
		celaligncenter.setHorizontalAlignment(JLabel.CENTER);
		
		jtable.getColumn("ID").setCellRenderer(celaligncenter);
		jtable.getColumn("이름").setCellRenderer(celaligncenter);
		
		jtable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		jtable.addMouseListener(this);
		
		jtable.addMouseMotionListener(this);
		
		
		
		jscrpane = new JScrollPane(jtable);
		//jscrpane.setBounds(10, 400, 570, 200);
		
		add(jscrpane);
		
		
		btnpanel = new JPanel();
		btnpanel.setLayout(new GridLayout(1,2,30,0));
		
		add(btnpanel,BorderLayout.SOUTH);
		
		deleteBtn = new JButton("선택회원 삭제");
		deleteBtn.addActionListener(this);
		btnpanel.add(deleteBtn);
		
		closeBtn = new JButton("나가기");
		closeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		
		btnpanel.add(closeBtn);
		
		
		setBounds(450, 250, 350, 450);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}


	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
