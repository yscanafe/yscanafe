package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;


import db.DBClose;
import db.DBConnection;
import model.BbsDto;
import single.singleton;


public class updateView extends JFrame implements ActionListener {

	JLabel  writer,idLb,num,contentLb,titleLb,wdateLb,wdate,countLb,count;
	
	JTextField titleTf;
	JTextArea writeTf;
	
	JScrollPane jscrpane;
	
	JButton registerBtn,closeBtn,deleteBtn;
	
	List<BbsDto> list;
	
	String id,content,title,realwdate,realcount;
	
	int seq;
	
	singleton s = singleton.getInstance();
	
	public updateView(int seq) {
		super("updateView");
		
		setLayout(null);

	
		list = s.bbsCtrl.getBbsList();
		
		this.seq = seq;
		
		for (int i = 0; i < list.size(); i++) {
			BbsDto bdto = list.get(i);
			
			if (seq == bdto.getSeq()) {
				
				id = bdto.getId();
				content = bdto.getContent();
				title = bdto.getTitle();
				realwdate = bdto.getWdate();
				realcount = String.valueOf(bdto.getReadcount());
				break;
			}
						
		}
		
		
		idLb = new JLabel(id);
		writer = new JLabel("작성자 : ");
		contentLb = new JLabel("내용 ");
		titleLb = new JLabel("제목 :");
		
		wdateLb = new JLabel("작성일 : ");
		wdate = new JLabel(realwdate);
		
		countLb = new JLabel("조회수 : ");
		count = new JLabel(realcount);
		
		idLb.setBounds(70, 10, 50, 30);
		writer.setBounds(10, 10, 70, 30);
		contentLb.setBounds(10, 160, 70, 30);
		
		wdateLb.setBounds(10, 40, 70, 30);
		wdate.setBounds(70, 40, 150, 30);
		
		countLb.setBounds(10, 70, 70, 30);
		count.setBounds(70, 70, 70, 30);
		
		titleLb.setBounds(10, 100, 70, 30);
		
		add(writer);
		add(idLb);
		add(contentLb);
		add(titleLb);
		
		add(wdateLb);
		add(wdate);
		
		add(countLb);
		add(count);
		
		writeTf = new JTextArea(content);
		writeTf.setLineWrap(true);
		writeTf.setBounds(10, 190, 400, 210);
		

		jscrpane = new JScrollPane(writeTf);
		jscrpane.setBounds(10, 190, 400, 210);
		jscrpane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add(jscrpane);
		
		
		titleTf = new JTextField(title);
		titleTf.setBounds(10, 130, 400, 30);
		
		
		add(titleTf);
		
		registerBtn = new JButton("등록");
		registerBtn.setBounds(10, 410, 100, 30);
		
		closeBtn = new JButton("취소");
		closeBtn.setBounds(310, 410, 100, 30);
		
		deleteBtn = new JButton("삭제");
		deleteBtn.setBounds(160, 410, 100, 30);
		
		registerBtn.addActionListener(this);
		closeBtn.addActionListener(this);
		deleteBtn.addActionListener(this);
		
		
		
		add(registerBtn);
		add(closeBtn);
		add(deleteBtn);
		
		setBounds(450, 200, 435, 500);
		
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		if (btn.getLabel().equals("등록")) {
		
			String title = titleTf.getText();
			String content = writeTf.getText();
			
			
			if (title.equals("")) {
				JOptionPane.showMessageDialog(null, "제목을  입력하세요.");
				return;
			}
			else if (content.equals("")) {
				JOptionPane.showMessageDialog(null, "내용을  입력하세요.");
				return;
			}
			
			s.bbsCtrl.updatebbs(seq, title, content);
			
						
			
			this.dispose();
			s.bbsCtrl.refreshbbs();
			
					
			
			
			
		}
		else if (btn.getLabel().equals("취소")) {
			this.dispose();
		}
		else if (btn.getLabel().equals("삭제")) {
			
			s.bbsCtrl.deletebbs(seq);
			
			
			this.dispose();
			s.bbsCtrl.refreshbbs();
			
			
		}

	}

}
