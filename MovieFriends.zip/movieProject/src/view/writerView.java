package view;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;


import db.DBClose;
import db.DBConnection;
import single.singleton;


public class writerView extends JFrame implements ActionListener{

	
	JComboBox mml;
	
	String[] malmerli;

	JLabel writer,idLb,num,writerLb,titleLb;
	
	JTextField titleTf;
	
	JTextField filetf;
	
	JScrollPane jscrpane;
	
	JTextArea writeTf;
	
	JButton registerBtn,closeBtn;
	
	
	JButton insertimg, insertfile;
	JButton filecancle;
	
	String id;
	
	String buffer1 = "" , buffer2 = "";
	
	Image img_insertimg = null;
	Image img_insertfile = null;
	Image img_insertedimg = null;
	
	
	String filePath = null; 
	
	
	public writerView(String id) {
		super("writerView");
		
		setLayout(null);
	
		
		singleton s = singleton.getInstance();
		this.id = s.memCtrl.id;
		
		idLb = new JLabel(id);
		writer = new JLabel("작성자 : ");
		writerLb = new JLabel("내용 입력");
		titleLb = new JLabel("제목 입력");
		
		idLb.setBounds(70, 10, 50, 30);
		writer.setBounds(10, 10, 70, 30);
		writerLb.setBounds(10, 120, 70, 30);
		
		titleLb.setBounds(10, 45, 70, 30);
		
		add(writer);
		add(idLb);
		add(writerLb);
		add(titleLb);

		
		
		
		
		
		
		writeTf = new JTextArea();
		//writeTf.setBounds(10, 150, 400, 250);
		writeTf.setLineWrap(true);
		
		
		/////////////
		///아이디가 관리자
		///auth로 바꾸기
		//////////////
		
	
		if(s.memCtrl.id.equals("admin")) {
			String[] malmerli =  {"","일반","정보","공지"};
			mml = new JComboBox(malmerli);
			mml.setBounds(15, 165, 75, 25);
			this.add(mml);
		}
		else {
			String[] malmerli =  {"","일반","정보"};
			mml = new JComboBox(malmerli);
			mml.setBounds(15, 165, 75, 25);
			this.add(mml);
		}
		
		
		insertfile = new JButton(new ImageIcon("file.png"));
		insertfile.setBounds(85, 165, 55, 25);
		insertfile.addActionListener(this);	
		add(insertfile);
		
		
		jscrpane = new JScrollPane(writeTf);
		jscrpane.setBounds(10, 190, 400, 210);
		jscrpane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add(jscrpane);
		
		
		
		titleTf = new JTextField();
		titleTf.setBounds(10, 75, 400, 30);
		
	
		filetf = new JTextField();
		filetf.setBounds(150, 165, 200, 25);
		
		add(titleTf);
		add(filetf);
		
		registerBtn = new JButton("등록");
		registerBtn.setBounds(10, 410, 100, 30);
		
		closeBtn = new JButton("취소");
		closeBtn.setBounds(310, 410, 100, 30);
		
		filecancle = new JButton("삭제");
		filecancle.setBounds(350, 165, 60, 25);
		
		
		registerBtn.addActionListener(this);
		closeBtn.addActionListener(this);
		filecancle.addActionListener(this);
		
		
		
		add(registerBtn);
		add(closeBtn);
		add(filecancle);
		
		
		
		
		setBounds(450, 200, 435, 500);
		
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {

		JButton btn = (JButton) e.getSource();
		
		singleton s = singleton.getInstance();
		
		if (btn.getLabel().equals("등록")) {
			
			String title = titleTf.getText();
			String content = writeTf.getText();
			
			
			if (title.equals("")) {
				JOptionPane.showMessageDialog(null, "제목을  입력하세요.");
				return;
			}
			else if (content.equals("")) {
				JOptionPane.showMessageDialog(null, "내용을  입력하세요.");
				return;
			}
			
			s.bbsCtrl.addbbs(id, title, content);
			
		
			
			
			
			this.dispose();
			s.bbsCtrl.refreshbbs();
			
			
			
			
		}
		else if (btn.getLabel().equals("취소")) {
			this.dispose();
		}
		
		else if (btn.getLabel().equals("삭제")) {
			filetf.setText(null);
			filePath = "";
		}
		else if (e.getSource()==insertfile) {
			JFileChooser chooser = new JFileChooser(); //객체 생성
				
			   int ret = chooser.showOpenDialog(null);  //열기창 정의
			   
			   buffer2 = "";
			 
			   if (ret != JFileChooser.APPROVE_OPTION) {

			    JOptionPane.showMessageDialog(null, "경로를 선택하지않았습니다.",

			      "경고", JOptionPane.WARNING_MESSAGE);

			    return;

			   }

			 
			   filePath = chooser.getSelectedFile().getPath();  //파일경로를 가져옴
			   filetf.setText(filePath);
			   
			   
			   //파일 버퍼에 불러오기
			  
			   File file = new File(filePath);
			   try {
					if(checkBeforeReadFile(file)) {
						
						// 문장으로 읽어들인다
						BufferedReader br = new BufferedReader(new FileReader(file));
						
						while((buffer1 = br.readLine()) != null) {
							buffer2 = buffer2 + "\r\n" + buffer1; 
						}
						System.out.println(buffer2);
						br.close();
						
						File file2 = new File("d:\\tmp\\newFile.txt");
						PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file2)));
						pw.write(buffer2);
						pw.print("\r\nmovie friends");
						pw.close();
										
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			   
			   
		}
		
	}
	

	static boolean checkBeforeReadFile(File f) {
		if(f.exists()) {
			if(f.isFile() && f.canRead()) {
				return true;
			}			
		}
		return false;		
	}	
}
