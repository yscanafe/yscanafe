package view;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;


import db.DBClose;
import db.DBConnection;
import single.singleton;

public class commentView extends JFrame implements ActionListener {

	JButton updateBtn,deleteBtn,closeBtn;
	
	JTextArea contentAr;
	
	int seq,conseq;
	
	String txt,id;
	
	
	
	public commentView(int seq, String id, int conseq) {
		super("댓글");
		
		this.seq = seq;
		this.id = id;
		this.conseq = conseq;
		
		setLayout(new FlowLayout());
		
		updateBtn = new JButton("수정");
		deleteBtn = new JButton("삭제");
		closeBtn = new JButton("취소");
		
		updateBtn.addActionListener(this);
		deleteBtn.addActionListener(this);
		closeBtn.addActionListener(this);
		
		add(updateBtn);
		add(deleteBtn);
		add(closeBtn);
		
		
		setBounds(400, 200, 220	, 80);
		//getContentPane().setBackground(Color.white);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		singleton s = singleton.getInstance();
		
		if (btn.getLabel().equals("수정")) {
		
			if (id.equals(s.bbsCtrl.id)) {
				s.bbsCtrl.commentupdateView(seq,conseq);
				this.dispose();
			}
			else JOptionPane.showMessageDialog(null, "수정할 권한이 없습니다.");
	
			
		}
		else if (btn.getLabel().equals("삭제")) {
			
			if (id.equals(s.bbsCtrl.id)) {
				s.bbsCtrl.deletecomment(seq);
				
				this.dispose();
				s.bbsCtrl.refreshcontent(conseq);
			}
			else JOptionPane.showMessageDialog(null, "삭제할 권한이 없습니다.");
			
			
			
			
			
		}
		else if (btn.getLabel().equals("취소")) {
			
			this.dispose();
		}
		
		
		
		
	}

	
	
	
}
