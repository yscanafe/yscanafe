package view;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import model.BbsDto;
import model.InterestDto;
import model.WatchDto;
import model.memberDto;
import single.singleton;


public class mypageView extends JFrame implements ActionListener, MouseListener {

	singleton s =  singleton.getInstance();
	List<BbsDto> bbsdtolist;
	
	//영화리스트, 게시판 ,달력,마이페이지 메뉴 버튼
		JButton movieBtn,bbsBtn,calendarBtn,mypageBtn;
	
		JPanel r,l;	// 판넬 양쪽1개씩
		JLabel id, name, email, point; 	// 정보 이름
		JLabel myid, myname, myemail, mypoint; //불러올 정보
		JLabel my; 		// 제목 ?
		
		Font f1;	// 폰트 
		
		JButton myupdate, poupdate; 	// 수정버튼 , 충전 버튼
	
		private JTable interT, watchT;
		private JScrollPane iJScr , wJscr;
		String intercolumn[] = {
				"번호", "제목", "배우", "감독", "포인트"
		};
		
		String watchcolumn[] = {
				"번호", "제목","배우" ,"포인트"," 본 날짜"
		};
		
		Object interData[][];
		
		Object watchData[][];
		DefaultTableModel iModel; // 관심 테이블 넓이 설정
		DefaultTableModel wModel;	// 시청한 테이블의 넓이 설정
		
		List<InterestDto> ilist;	
		List<WatchDto> wlist;
	public mypageView(List<InterestDto> ilist, List<WatchDto> wlist) {
		super("마이페이지");
	
		this.ilist = ilist;
		this.wlist = wlist;
			setLayout(null);
		//영화리스트,게시판, 달력, 마이페이지
	
			
			
		String cur = System.getProperty("user.dir");
		System.out.println("cur:" + cur);
		
		movieBtn = new JButton("영화");
		bbsBtn = new JButton("게시판");
		calendarBtn = new JButton("달력");
		mypageBtn = new JButton("마이페이지");
		
		movieBtn.setBounds(10, 10, 100, 30);
		bbsBtn.setBounds(120, 10, 100, 30);
		calendarBtn.setBounds(230, 10, 100, 30);
		mypageBtn.setBounds(340, 10, 100, 30);
		
		movieBtn.addActionListener(this);
		bbsBtn.addActionListener(this);
		calendarBtn.addActionListener(this);
		mypageBtn.addActionListener(this);
		
		add(bbsBtn);
		add(calendarBtn);
		add(movieBtn);
		add(mypageBtn);
		
		f1 = new Font("바탕", Font.ITALIC, 30);
		
		id = new JLabel("Id :");
		id.setBounds(50, 350, 150, 50);
		id.setFont(f1);
		add(id);
		
		myid = new JLabel();
		myid.setBounds(150, 350, 150, 50);
		myid.setFont(f1);
		add(myid);
		
		name = new JLabel("이름 :");
		name.setBounds(50, 420, 150, 50);
		name.setFont(f1);
		add(name);
		
		myname = new JLabel("aaaa");
		myname.setBounds(150, 420, 150, 50);		
		myname.setFont(f1);
		add(myname);
		
		email = new JLabel("E-mail :");
		email.setBounds(50, 490, 150, 50);
		email.setFont(f1);
		add(email);
		
		myemail = new JLabel("aa@aaaa.com");
		myemail.setBounds(200, 490, 150, 50);
		myemail.setFont(f1);
		add(myemail);
		
		point = new JLabel("내 포인트");
		point.setBounds(350, 350, 150, 50);
		point.setFont(f1);
		add(point);
		
		mypoint = new JLabel("12331p");
		mypoint.setBounds(350, 420, 150, 50);
		mypoint.setFont(f1);
		add(mypoint);
		
		myupdate = new JButton("정보 수정");
		myupdate.setBounds(50, 600, 150, 50);
		myupdate.addActionListener(this);
		add(myupdate);
		
		poupdate = new JButton("포인트 충전");
		poupdate.setBounds(350, 600, 150, 50);
		poupdate.addActionListener(this);
		add(poupdate);
		
		r = new JPanel();
		r.setBounds(40, 300, 640, 400);
		r.setLayout(null);
		r.setBackground(Color.white);
		add(r);
		
		l = new JPanel();
		l.setBounds(700, 300, 640, 400);
		
		l.setLayout(null);
		l.setBackground(Color.white);
		
		
		
		
		int iLen = ilist.size();
		int iNum = 1;
		
		interData = new Object[iLen][5];
		
		for(int i = 0;i < iLen; i++){
			InterestDto dto = ilist.get(i);			
			interData[i][0] = iNum;
			if(dto.getDel() == 1) {
				interData[i][1] = "이 글은 삭제되었습니다";
			}else {
				interData[i][1] = dto.getTitle();
			}
			interData[i][2] = dto.getActer();
			interData[i][3] = dto.getDerecter();
			interData[i][4] = dto.getPoint();
		
			iNum++;
		}
		
		iModel = new DefaultTableModel(intercolumn, 0);
		iModel.setDataVector(interData, intercolumn);
		
		interT = new JTable(iModel);
		interT.addMouseListener(this);
		
		interT.getColumnModel().getColumn(0).setMaxWidth(50); // 번호폭
		interT.getColumnModel().getColumn(1).setMaxWidth(200);// 제목 폭
		interT.getColumnModel().getColumn(2).setMaxWidth(200);// 배우 폭
		interT.getColumnModel().getColumn(3).setMaxWidth(100);// 감독 폭
		interT.getColumnModel().getColumn(4).setMaxWidth(50);// 포인트 폭
	
		int wLen = wlist.size();
		int wNum = 1;
		
		watchData = new Object[wLen][5];
		
		for(int i = 0;i < wLen; i++){
			WatchDto dto = wlist.get(i);			
			watchData[i][0] = wNum;
			if(dto.getDel() == 1) {
				watchData[i][1] = "이 글은 삭제되었습니다";
			}else {
				watchData[i][1] = dto.getTitle();
			}
			watchData[i][2] = dto.getActer();
			watchData[i][3] = dto.getPoint();
			watchData[i][4] = dto.getwDate();
			wNum++;
		}
		
		wModel = new DefaultTableModel(watchcolumn, 0);
		wModel.setDataVector(watchData, watchcolumn);
		
		watchT = new JTable(wModel);
		watchT.addMouseListener(this);
		
		watchT.getColumnModel().getColumn(0).setMaxWidth(50); // 번호폭
		watchT.getColumnModel().getColumn(1).setMaxWidth(200);// 제목 폭
		watchT.getColumnModel().getColumn(2).setMaxWidth(200);// 배우 폭
		watchT.getColumnModel().getColumn(3).setMaxWidth(50);// 포인트 폭
		watchT.getColumnModel().getColumn(4).setMaxWidth(100);// 날짜 폭
		
		iJScr = new JScrollPane(interT);
		iJScr.setBounds(720, 340, 600, 150);
		iJScr.setVisible(true);
		add(iJScr);
		
		wJscr = new JScrollPane(watchT);
		wJscr.setBounds(720, 510, 600, 150);
		wJscr.setVisible(true);
		add(wJscr);
		
		
		add(l);
		
		
		setBounds(20, 20, 1400, 800);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		

	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		if (btn.getLabel().equals("영화")) {
			this.dispose();
			new movieListView();
		}
		else if (btn.getLabel().equals("게시판")) {
			this.dispose();
			singleton s = singleton.getInstance();
			new bbsListView(bbsdtolist);
		}
		else if (btn.getLabel().equals("달력")) {
			this.dispose();
			new calendarView();
		}
		else if (btn.getLabel().equals("마이페이지")) {
			this.dispose();
			//new mypageView();
		}

	}


	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
