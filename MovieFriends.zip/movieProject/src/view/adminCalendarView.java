package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import model.BbsDto;
import model.calendarDto;
import single.singleton;

public class adminCalendarView extends JFrame implements ActionListener, MouseListener {

	
	String columnNames[] = { "이벤트명","시작날짜" ,"종료날짜","컬러"};
	
	DefaultTableModel model;
	
	Object rowdata[][];
	
	JTable jtable;
	
	JScrollPane jscrpane;
	
	JButton closeBtn,deleteBtn,insertBtn;
	JPanel btnpanel;
	
	singleton s = singleton.getInstance();
	
	List<calendarDto> list;
	
	String checkname = null;
	
	int row[],seq;
	
	public adminCalendarView() {
		super("달력관리");
		
		setLayout(new BorderLayout());
		
		list = s.calCtrl.getevent();
		
		rowdata = new Object[list.size()][4]; 	// 테이블의 2차원 배열 생성
		row = new int[list.size()];
		
		
		for (int i = 0; i < list.size(); i++) {
			calendarDto dto = list.get(i);
			
			rowdata[i][0] = dto.getEventname();
			rowdata[i][1] = dto.getStartday();
			rowdata[i][2] = dto.getEndday();
			rowdata[i][3] = dto.getColor();
			row[i] = dto.getSeq();
			
			
		}
		
		
		model = new DefaultTableModel(columnNames, 0) {
			public boolean isCellEditable(int i,int c) {
				return false;
			}
		};
		
		model.setDataVector(rowdata, columnNames);
		
		jtable = new JTable(model);
		// 컬럼 넓이 설정
	/*	jtable.getColumnModel().getColumn(0).setMaxWidth(50);	// 번호 폭
		jtable.getColumnModel().getColumn(1).setMaxWidth(70);	// 작성자 폭
		jtable.getColumnModel().getColumn(2).setMaxWidth(0);	// 내용 폭
	*/
		
		jtable.setRowHeight(15);
		
		// 테이블 안의 컬럼의 align 설정
		DefaultTableCellRenderer celaligncenter = new DefaultTableCellRenderer();
		celaligncenter.setHorizontalAlignment(JLabel.CENTER);
		
		jtable.getColumn("이벤트명").setCellRenderer(celaligncenter);
		jtable.getColumn("시작날짜").setCellRenderer(celaligncenter);
		
		jtable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		jtable.addMouseListener(this);
		
		//jtable.addMouseMotionListener(this);
		
		
		
		jscrpane = new JScrollPane(jtable);
		//jscrpane.setBounds(10, 400, 570, 200);
		
		add(jscrpane);
		

		
		btnpanel = new JPanel();
		btnpanel.setLayout(new GridLayout(1,3,30,0));
		
		add(btnpanel,BorderLayout.SOUTH);
		
		
		
		deleteBtn = new JButton("선택 삭제");
		deleteBtn.addActionListener(this);
		btnpanel.add(deleteBtn);
		
		insertBtn = new JButton("이벤트 추가");
		insertBtn.addActionListener(this);
		btnpanel.add(insertBtn);
		
		
		closeBtn = new JButton("나가기");
		closeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		
		btnpanel.add(closeBtn);
		
		
		
		
		setBounds(450, 250, 650, 450);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		if (obj == insertBtn) {
			s.adminCtrl.adminCalendarInsertView();
		}
		else if (obj == deleteBtn) {
			
			if (checkname == null) {
				JOptionPane.showMessageDialog(null, "선택된 항목이 없습니다.");
				return;
			}
			
			int check = JOptionPane.showConfirmDialog(null, "이벤트 제목 : "+checkname+" 을 삭제하시겠습니까?","삭제확인",
					JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
			if (check ==0) {
				s.calCtrl.deleteEvent(seq);
				this.dispose();
				s.adminCtrl.adminCalendarView();
			}
			
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		seq = (int) row[jtable.getSelectedRow()];
		checkname = (String) rowdata[jtable.getSelectedRow()][0];
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
