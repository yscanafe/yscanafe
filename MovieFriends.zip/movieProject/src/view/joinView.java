package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import single.singleton;


public class joinView extends JFrame implements ActionListener, WindowListener{

	private JTextField idTf, pwTf, nameTf, emailTf;
	private JButton loginBtn, idConBtn;
	
	public joinView() {
		super("회원가입");
		
		setLayout(null);
		
		JLabel idLable = new JLabel("ID");
		idLable.setBounds(30, 30, 50, 30);
		add(idLable);
		
		JLabel pwLable = new JLabel("PW");
		pwLable.setBounds(30, 80, 50, 30);
		add(pwLable);
		
		JLabel nameLable = new JLabel("Name");
		nameLable.setBounds(30, 130, 50, 30);
		add(nameLable);
		
		JLabel emailLable = new JLabel("Email");
		emailLable.setBounds(30, 180, 50, 30);
		add(emailLable);
		
		idTf = new JTextField();
		idTf.setBounds(70, 30, 135, 30);
		add(idTf);
		
		pwTf = new JTextField();
		pwTf.setBounds(70, 80, 230, 30);
		add(pwTf);
		
		nameTf = new JTextField();
		nameTf.setBounds(70, 130, 230, 30);
		add(nameTf);
		
		emailTf = new JTextField();
		emailTf.setBounds(70, 180, 230, 30);
		add(emailTf);
		
		loginBtn = new JButton("회원가입");
		loginBtn.setBounds(80, 230, 150, 80);
		loginBtn.addActionListener(this);
		add(loginBtn);
		
		idConBtn = new JButton("중복확인");
		idConBtn.setBounds(210, 30, 88, 30);
		idConBtn.addActionListener(this);
		add(idConBtn);
		
		setBounds(550, 250, 340, 380);
		setVisible(true);
		addWindowListener(this);

		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton jb = (JButton)e.getSource();
		String jbStr = jb.getLabel();
		
		singleton s = singleton.getInstance();
		boolean b = s.memCtrl.idCheck(idTf.getText());
		if(jbStr.equals("중복확인")){
			if(b){
				JOptionPane.showMessageDialog(null, "사용할 수 없는 아이디 입니다");
				idTf.setText("");
			}
			else {
				JOptionPane.showMessageDialog(null, "사용할 수 있는 ID입니다");
			}
	}
		else if(jbStr.equals("회원가입")){
			s.memCtrl.regiAf(idTf.getText(), pwTf.getText(),
					nameTf.getText(), emailTf.getText());
			this.dispose();
		}
	}


	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		System.exit(0);
	}


	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

}
