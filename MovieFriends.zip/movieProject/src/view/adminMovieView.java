package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class adminMovieView extends JFrame implements ActionListener, MouseListener {


	String columnNames[] = { "영화명","개봉일" ,"평점"};
	
	DefaultTableModel model;
	
	Object rowdata[][];
	
	JTable jtable;
	
	JScrollPane jscrpane;
	
	JButton closeBtn,deleteBtn,insertBtn;
	JPanel btnpanel;
	
	
	
	public adminMovieView() {
		super("영화관리");
	
		setLayout(new BorderLayout());
		
		model = new DefaultTableModel(columnNames, 0) {
			public boolean isCellEditable(int i,int c) {
				return false;
			}
		};
		
		model.setDataVector(rowdata, columnNames);
		
		jtable = new JTable(model);
		// 컬럼 넓이 설정
		jtable.getColumnModel().getColumn(0).setMaxWidth(200);	// 번호 폭
		jtable.getColumnModel().getColumn(1).setMaxWidth(100);	// 작성자 폭
		jtable.getColumnModel().getColumn(2).setMaxWidth(50);	// 내용 폭

		
		jtable.setRowHeight(15);
		
		// 테이블 안의 컬럼의 align 설정
		DefaultTableCellRenderer celaligncenter = new DefaultTableCellRenderer();
		celaligncenter.setHorizontalAlignment(JLabel.CENTER);
		
		jtable.getColumn("영화명").setCellRenderer(celaligncenter);
		jtable.getColumn("개봉일").setCellRenderer(celaligncenter);
		
		jtable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		jtable.addMouseListener(this);
		
		//jtable.addMouseMotionListener(this);
		
		
		
		jscrpane = new JScrollPane(jtable);
		//jscrpane.setBounds(10, 400, 570, 200);
		
		add(jscrpane);
		
	
		
		btnpanel = new JPanel();
		btnpanel.setLayout(new GridLayout(1,3,30,0));
		
		add(btnpanel,BorderLayout.SOUTH);
		
		
		
		deleteBtn = new JButton("선택 삭제");
		deleteBtn.addActionListener(this);
		btnpanel.add(deleteBtn);
		
		insertBtn = new JButton("영화 추가");
		insertBtn.addActionListener(this);
		btnpanel.add(insertBtn);
		
		
		closeBtn = new JButton("나가기");
		closeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		
		btnpanel.add(closeBtn);
		
		
		setBounds(450, 250, 350, 450);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

		Object obj = e.getSource();
		
		if (obj == insertBtn) {
			new adminMovieInsertView();
		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
