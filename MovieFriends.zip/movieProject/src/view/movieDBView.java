package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class movieDBView extends JFrame implements ActionListener {

	
	JButton playBtn;
	
	public movieDBView() {
		super("영화정보");
		
		setLayout(null);
		
		playBtn = new JButton("바로보기");
		playBtn.setBounds(250, 350, 100, 30);
		playBtn.addActionListener(this);
		add(playBtn);
		
		
		
		setBounds(450, 250, 600, 480);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		
		if (btn.getLabel().equals("바로보기")) {
			new playView();
		}
		
		
	}

}
