package view;

import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class adminMovieInsertView extends JFrame implements ActionListener {
	
	Label nameLable,startLable,directorLabel,actorLabel,storyLabel,timeLabel;
	
	JTextField nameTf,startTf,directorTf,actorTf,timeTf;
	
	JButton closeBtn, insertBtn,idconfig;
	
	JTextArea storyTf;
	JScrollPane jscrpane;
	
	public adminMovieInsertView() {
		super("영화 추가");
		
		setLayout(null);
		
		
		
		nameLable = new Label("영화 제목 :");
		nameLable.setBounds(30, 50, 60, 30);
		
		startLable = new Label("개봉일 :");
		startLable.setBounds(30, 100, 60, 30);
		
		directorLabel = new Label("감독 :");
		directorLabel.setBounds(30, 150, 50, 30);
		
		actorLabel = new Label("배우 :");
		actorLabel.setBounds(30, 200, 50, 30);
		
		timeLabel = new Label("상영 시간 : ");
		timeLabel.setBounds(30, 250, 60, 30);
		
		storyLabel = new Label("줄거리");
		storyLabel.setBounds(30, 300, 60, 30);
		
		

		add(nameLable);
		add(startLable);
		add(directorLabel);
		add(actorLabel);
		add(timeLabel);
		add(storyLabel);
		
		
		
		
		storyTf = new JTextArea();
		//writeTf.setBounds(10, 150, 400, 250);
		storyTf.setLineWrap(true);
		
		jscrpane = new JScrollPane(storyTf);
		jscrpane.setBounds(10, 330, 400, 220);
		jscrpane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		add(jscrpane);
		
		
		nameTf = new JTextField();
		nameTf.setBounds(100, 50, 170, 30);
		
		startTf = new JTextField();
		startTf.setBounds(100, 100, 170, 30);
		
		directorTf = new JTextField();
		directorTf.setBounds(100, 150, 170, 30);
		
		actorTf = new JTextField();
		actorTf.setBounds(100, 200, 170, 30);
		
		timeTf = new JTextField();
		timeTf.setBounds(100, 250, 170, 30);
		
		
		add(nameTf);
		add(startTf);
		add(directorTf);
		add(actorTf);
		add(timeTf);
		
	
		
		
		insertBtn = new JButton("추가하기");
		insertBtn.setBounds(10, 575, 100, 30);
		
		closeBtn = new JButton("취소");
		closeBtn.setBounds(310, 575, 100, 30);
		
	
		
		closeBtn.addActionListener(this);
		insertBtn.addActionListener(this);
	
		
		
		add(closeBtn);
		add(insertBtn);
		

		
		setBounds(450, 200, 435, 650);
		
		
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}
