package model;

/*

DROP TABLE MOVIECALENDAR
CASCADE CONSTRAINTS;

CREATE TABLE MOVIECALENDAR(
SEQ NUMBER(8) PRIMARY KEY,
EVENTNAME VARCHAR2(1000) NOT NULL,
STARTDAY DATE NOT NULL,
ENDDAY DATE NOT NULL,
COLOR VARCHAR2(50) NOT NULL
);

CREATE SEQUENCE SEQ_CALENDAR
START WITH 1
INCREMENT BY 1;

SELECT * FROM MOVIECALENDAR;

INSERT INTO MOVIECALENDAR
VALUES (SEQ_CALENDAR.NEXTVAL,'7일간 신과함께 무료!','2018-08-01','2018-08-07','RED');

INSERT INTO MOVIECALENDAR
VALUES (SEQ_CALENDAR.NEXTVAL,'7일간 레슬러 무료!','2018-08-08','2018-08-14','YELLOW');

INSERT INTO MOVIECALENDAR
VALUES (SEQ_CALENDAR.NEXTVAL,'7일간 독전 무료!','2018-08-29','2018-09-04','GREEN');


 
 */


public class calendarDto {

	private int seq;
	private String eventname;
	private String startday;
	private String endday;
	private String color;
	
	public calendarDto() {
		// TODO Auto-generated constructor stub
	}

	public calendarDto(int seq, String eventname, String startday, String endday, String color) {
		super();
		this.seq = seq;
		this.eventname = eventname;
		this.startday = startday;
		this.endday = endday;
		this.color = color;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public String getStartday() {
		return startday;
	}

	public void setStartday(String startday) {
		this.startday = startday;
	}

	public String getEndday() {
		return endday;
	}

	public void setEndday(String endday) {
		this.endday = endday;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "calendarDto [seq=" + seq + ", eventname=" + eventname + ", startday=" + startday + ", endday=" + endday
				+ ", color=" + color + "]";
	}

	
	
}
