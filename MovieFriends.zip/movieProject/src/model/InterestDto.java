package model;
/*
DROP TABLE INTERESTTABLE;
CASCADE CONSTRAINTS;

CREATE TABLE INTERESTTABLE(
	SEQ NUMBER(8) PRIMARY KEY,
	ID VARCHAR2(50) NOT NULL,
	TITLE VARCHAR2(200) NOT NULL,
	ACTER VARCHAR2(200) NOT NULL,
	DERECTER VARCHAR2(200) NOT NULL,
	POINT VARCHAR2(50) NOT NULL,
	DEL NUMBER(1) NOT NULL
);
// 임시데이터
INSERT INTO INTERESTTABLE(SEQ, ID, TITLE, ACTER, DERECTER,POINT,DEL) 
			 VALUES('2', 'a','레옹','장 르노, 나탈리 포트만','뤽 베송','100','0')

CREATE SEQUENCE SEQ_INTERESTTABLE
START WITH 1
INCREMENT BY 1;

ALTER TABLE INTERESTTABLE
ADD CONSTRAINT FK_INTERESTTABLE_ID FOREIGN KEY(ID)
REFERENCES MEMBER(ID);

SELECT * FROM INTERESTTABLE;
 */
public class InterestDto {
	
	private int seq;
	private String id;
	private String title;
	private String acter;
	private String derecter;
	private String point;
	private int del;
	
	public InterestDto() {
		
	}

	public InterestDto(int seq, String id, String title, String acter, String derecter, String point, int del) {
		super();
		this.seq = seq;
		this.id = id;
		this.title = title;
		this.acter = acter;
		this.derecter = derecter;
		this.point = point;
		this.del = del;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActer() {
		return acter;
	}

	public void setActer(String acter) {
		this.acter = acter;
	}

	public String getDerecter() {
		return derecter;
	}

	public void setDerecter(String derecter) {
		this.derecter = derecter;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public int getDel() {
		return del;
	}

	public void setDel(int del) {
		this.del = del;
	}

	@Override
	public String toString() {
		return "InterestDto [seq=" + seq + ", id=" + id + ", title=" + title + ", acter=" + acter + ", derecter="
				+ derecter + ", point=" + point + ", del=" + del + "]";
	}
	
}
