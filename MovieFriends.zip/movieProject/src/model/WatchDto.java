package model;
/*
 * DROP TABLE WATCHTABLE;
CASCADE CONSTRAINTS;

CREATE TABLE WATCHTABLE(
	SEQ NUMBER(8) PRIMARY KEY,
	ID VARCHAR2(50) NOT NULL,
	TITLE VARCHAR2(200) NOT NULL,
	ACTER VARCHAR2(200) NOT NULL,
	POINT VARCHAR2(50) NOT NULL,
	WDATE VARCHAR2(200) NOT NULL,
	DEL NUMBER(1) NOT NULL
);
// 임시데이터
INSERT INTO WATCHTABLE(SEQ, ID, TITLE, ACTER, POINT, WDATE, DEL) 
			 VALUES('2', 'b','남한산성','이병헌,김윤석,박해일','120','18/08/08','0')

CREATE SEQUENCE SEQ_WATCHTABLE
START WITH 1
INCREMENT BY 1;

ALTER TABLE WATCHTABLE
ADD CONSTRAINT FK_WATCHTABLE_ID FOREIGN KEY(ID)
REFERENCES MEMBER(ID);

SELECT * FROM WATCHTABLE;
 */
public class WatchDto {
	
	private int seq;
	private String id;
	private String title;
	private String acter;
	private String point;
	private String wDate;
	private int del;
	
	public WatchDto() {
		
	}

	public WatchDto(int seq, String id, String title, String acter, String point, String wDate, int del) {
		super();
		this.seq = seq;
		this.id = id;
		this.title = title;
		this.acter = acter;
		this.point = point;
		this.wDate = wDate;
		this.del = del;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActer() {
		return acter;
	}

	public void setActer(String acter) {
		this.acter = acter;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public String getwDate() {
		return wDate;
	}

	public void setwDate(String wDate) {
		this.wDate = wDate;
	}

	public int getDel() {
		return del;
	}

	public void setDel(int del) {
		this.del = del;
	}

	@Override
	public String toString() {
		return "WatchDto [seq=" + seq + ", id=" + id + ", title=" + title + ", acter=" + acter + ", point=" + point
				+ ", wDate=" + wDate + ", del=" + del + "]";
	}
	
	
}
