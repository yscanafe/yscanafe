package model;

/*
DROP TABLE MYPAGETABLE;
CASCADE CONSTRAINTS;

CREATE TABLE MYPAGETABLE(
NUM VARCHAR2(50) NOT NULL,
TITLE VARCHAR2(50) NOT NULL,
POINT VARCHAR2(50) NOT NULL,
WATCHDATE VARCHAR2(50) NOT NULL
);

SELECT * FROM MYPAGETABLE;
 */
public class MyPageDto {

/*	private String num;
	private String title;
	private	String point;
	private String watchdate;
	
	
	public MyPageDto() {
		
	}

	

	public MyPageDto(String num, String title, String point, String watchdate) {
		super();
		this.num = num;
		this.title = title;
		this.point = point;
		this.watchdate = watchdate;
	}



	public MyPageDto(String num, String title, String point) {
		super();
		this.num = num;
		this.title = title;
		this.point = point;
	}



	public String getNum() {
		return num;
	}



	public void setNum(String num) {
		this.num = num;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getPoint() {
		return point;
	}



	public void setPoint(String point) {
		this.point = point;
	}



	public String getWatchdate() {
		return watchdate;
	}



	public void setWatchdate(String watchdate) {
		this.watchdate = watchdate;
	}



	@Override
	public String toString() {
		return "MyPageDto [num=" + num + ", title=" + title + ", point=" + point + ", watchdate=" + watchdate + "]";
	}*/


	
	
	
}
