package Service;

import java.util.List;

import dao.bbsDao;
import dao.bbsDaoImpl;
import model.BbsDto;
import model.CommentDto;

public class BBSService implements BBSServiceImpl {

	bbsDaoImpl dao = new bbsDao();
	
	
	@Override
	public List<BbsDto> getBbsList() {
		// TODO Auto-generated method stub
		return dao.getBbsList();
	}


	@Override
	public void addbbs(String id, String title, String content) {
		// TODO Auto-generated method stub
		dao.addbbs(id, title, content);
	}
	
	

	@Override
	public void addcount(int seq) {
		dao.addcount(seq);
		
	}


	@Override
	public void updatebbs(int seq, String title, String content) {
		// TODO Auto-generated method stub
		dao.updatebbs(seq, title, content);
	}


	@Override
	public void deletebbs(int seq) {
		// TODO Auto-generated method stub
		dao.deletebbs(seq);
	}


	@Override
	public List<BbsDto> getsearchlist(String str, int option) {
		// TODO Auto-generated method stub
		return dao.getsearchlist(str, option);
	}


	@Override
	public List<CommentDto> getcomlist(int seq) {
		// TODO Auto-generated method stub
		return dao.getcomlist(seq);
	}


	@Override
	public void addcomment(int seq, String id, String content) {
		// TODO Auto-generated method stub
		dao.addcomment(seq, id, content);
		
	}


	@Override
	public void deletecomment(int seq) {
		// TODO Auto-generated method stub
		dao.deletecomment(seq);
	}


	@Override
	public void updatecomment(int seq, String content) {
		// TODO Auto-generated method stub
		dao.updatecomment(seq, content);
	}


	

	
	
	
	
}
