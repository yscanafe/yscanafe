package Service;

import java.util.List;

import model.memberDto;

public interface MemberServiceImpl {

	boolean getId(String id);

	public boolean addMember(memberDto dto);

	
}
