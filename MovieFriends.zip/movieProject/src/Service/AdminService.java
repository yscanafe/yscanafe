package Service;

public class AdminService implements AdminServiceImpl {

}
