package Service;

import java.util.List;

import dao.calendarDao;
import dao.calendarDaoImpl;
import model.calendarDto;

public class CalendarService implements CalendarServiceImpl {

	
	calendarDaoImpl dao = new calendarDao();
	
	@Override
	public List<calendarDto> getevent() {
		// TODO Auto-generated method stub
		return dao.getevent();
	}

	@Override
	public void insertevent(calendarDto dto) {
		// TODO Auto-generated method stub
		dao.insertevent(dto);
	}

	@Override
	public void deleteEvent(int seq) {
		// TODO Auto-generated method stub
		dao.deleteEvent(seq);
	}

}
