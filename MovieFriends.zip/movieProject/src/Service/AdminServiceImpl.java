package Service;

public interface AdminServiceImpl {

}
