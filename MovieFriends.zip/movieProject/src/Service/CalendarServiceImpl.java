package Service;

import java.util.List;

import model.calendarDto;

public interface CalendarServiceImpl {

	
	
	
	public List<calendarDto> getevent();
	
	public void insertevent(calendarDto dto);
	
	public void deleteEvent(int seq);
	
}
