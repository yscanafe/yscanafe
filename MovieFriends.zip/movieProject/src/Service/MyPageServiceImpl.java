package Service;

import java.util.List;

import model.InterestDto;
import model.WatchDto;

public interface MyPageServiceImpl {
	
	public InterestDto getInterest(int seq);
	public List<InterestDto> getInterestlist();
	public boolean writeInterest(InterestDto dto);
	public boolean deleteInterest(int seq);
	
	public WatchDto getWatch(int seq);
	public List<WatchDto> getWatchlist();
	public boolean writeWatch(WatchDto dto);
	public boolean deleteWatch(int seq);
}
