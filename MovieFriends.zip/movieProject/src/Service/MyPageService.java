package Service;

import java.util.List;

import dao.InterestDao;
import dao.InterestDaoImpl;
import dao.WatchDao;
import dao.WatchDaoImpl;
import model.InterestDto;
import model.WatchDto;

public class MyPageService implements MyPageServiceImpl {

	WatchDaoImpl wDao = new WatchDao();
	
	InterestDaoImpl dao = new InterestDao();

	@Override
	public InterestDto getInterest(int seq) {
		
		return dao.getInterest(seq);
	}

	@Override
	public List<InterestDto> getInterestlist() {
		
		return dao.getInterestlist();
	}

	@Override
	public boolean writeInterest(InterestDto dto) {
		
		return dao.writeInterest(dto);
	}

	@Override
	public boolean deleteInterest(int seq) {
	
		return dao.deleteInterest(seq);
	}

	@Override
	public WatchDto getWatch(int seq) {
		
		return wDao.getWatch(seq);
	}

	@Override
	public List<WatchDto> getWatchlist() {
		// TODO Auto-generated method stub
		return wDao.getWatchlist();
	}

	@Override
	public boolean writeWatch(WatchDto dto) {
		// TODO Auto-generated method stub
		return wDao.writeWatch(dto);
	}

	@Override
	public boolean deleteWatch(int seq) {
		// TODO Auto-generated method stub
		return wDao.deleteWatch(seq);
	}
	
}
