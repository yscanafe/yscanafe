package Service;

import java.util.List;

import dao.memberDao;
import dao.memberDaoImpl;
import model.memberDto;

public class MemberService implements MemberServiceImpl {

	memberDaoImpl dao = new memberDao();

	@Override
	public boolean getId(String id) {
		return dao.getId(id);
	}

	@Override
	public boolean addMember(memberDto dto) {
		return dao.addMember(dto);
	}
	
	
}
