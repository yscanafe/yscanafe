package Service;

public interface MovieServiceImpl {

}
