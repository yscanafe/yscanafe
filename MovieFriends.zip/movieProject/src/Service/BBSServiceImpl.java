package Service;

import java.util.List;

import model.BbsDto;
import model.CommentDto;

public interface BBSServiceImpl {

	
	public List<BbsDto> getBbsList();
	public void addbbs(String id, String title, String content);
	public void addcount(int seq);
	
	public void updatebbs(int seq,String title, String content);
	public void deletebbs(int seq);
	
	public List<BbsDto> getsearchlist(String str, int option);
	
	
	public List<CommentDto> getcomlist(int seq);
	public void addcomment(int seq,String id,String content);
	
	public void deletecomment(int seq);
	
	public void updatecomment(int seq,String content);
	
}
