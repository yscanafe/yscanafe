package Service;

public class MovieService implements MovieServiceImpl {

}
