package single;

import Controller.AdminCtr;
import Controller.BBSListCtr;
import Controller.CalendarCtr;
import Controller.MemberCtr;
import Controller.MyPageCtr;
import dao.memberDao;



public class singleton {

	private static singleton s = new singleton();
		public MemberCtr memCtrl;
		public CalendarCtr calCtrl;
		public MyPageCtr myPageCtrl;
		public BBSListCtr bbsCtrl;
		public AdminCtr adminCtrl;
	private singleton() {
		memCtrl = new MemberCtr();
		calCtrl = new CalendarCtr();
		myPageCtrl = new MyPageCtr();
		bbsCtrl = new BBSListCtr();
		adminCtrl = new AdminCtr();
	}
	
	public static singleton getInstance() {
		return s;
	};
	
}
