package kh.c.five.model;

import java.io.Serializable;

public class RestaurantDto implements Serializable {
	
	private int seq;
	private String rs_name;
	private String rs_address1;
	private String rs_address2;
	private String rs_picture;
	private String rs_category;
	private String rs_menu;
	private int rs_rating;
	private int rs_readcount;
	
	

}
